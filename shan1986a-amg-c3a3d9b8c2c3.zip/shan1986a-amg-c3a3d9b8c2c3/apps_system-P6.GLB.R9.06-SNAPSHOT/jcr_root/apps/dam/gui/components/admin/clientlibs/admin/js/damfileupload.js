(function(document, $) {
	"use strict";

     var MODAL_HTML =
            "<div class=\"coral-Modal-header\">"
			+ "<h2 class=\"coral-Modal-title coral-Heading coral-Heading--2\"></h2>"
			+ "<i class=\"coral-Modal-typeIcon coral-Icon coral-Icon--sizeS\"></i>"
			+ "<button type=\"button\" "
			+ "class=\"coral-MinimalButton coral-Modal-closeButton\" "
			+ "data-dismiss=\"modal\">"
			+ "<i class=\"coral-Icon coral-Icon--sizeXS coral-Icon--close "
			+ "coral-MinimalButton-icon\"></i>" + "</button>" + "</div>"
			+ "<div class=\"coral-Modal-body legacy-margins\"></div>"
			+ "<div class=\"coral-Modal-footer\"></div>";
		  
	var duplicateAssets = [];

	var CUIFileUpload = {};

	var fileObjects = {};
    
	var chunkRetryHanlder;

	var manualPause = false;

    // CQ-26711: Disable multiple file upload on touch devices
    $(document).on("foundation-contentloaded", function(e) {
        if (CUI.util.isTouch) {
            $(".coral-FileUpload-trigger > input").removeAttr("multiple");
        }
    });

	function closeBrowserWarning() {
		return Granite.I18n.get('Upload is in Progress. Refreshing page will lose the files that have not completed the upload.');
	}
	function cleanup(event) {
        window.onbeforeunload = null;
        window.damFileUploadSucces = 0;
        event.fileUpload.list = [];
        event.fileUpload.uploadQueue.length = 0;
        event.fileUpload.rejectedFiles = [];
        resetFileInput(event.fileUpload.$element);
	}
	/**
	 * will be called up on fileuploadsuccess, fileuploaderror and fileuploadcanceled.
	 * when all the files have beend processed, then refreshes the content and
	 * returns true otherwise returns false;
	 */
	function refresh(event) {
		window.damUploadedFilesCount = window.damUploadedFilesCount || 0;
		window.damUploadedFilesCount++;
		if (window.damUploadedFilesCount === window.damTotalFilesForUpload) {
			window.damUploadedFilesCount = 0;
			window.damTotalFilesForUpload = 0;
			// clean onbeforeunload
			window.onbeforeunload = null;

			//refresh foundation-content
			var contentApi = $(".foundation-content").adaptTo("foundation-content");
			contentApi.refresh();
			//refresh renditions if assetdetails page
			var assetDetails = location.href.indexOf("assetdetails.html/") != -1 ? true : false;
			if (assetDetails) {
				$(document).trigger("show-asset-renditions");
			}

			//show success notification
			var showNotifications = event.fileUpload.inputElement.data('showNotifications');
			if (showNotifications) {
				//hide the previous notifications if any
				$(".coral-Alert.coral-Alert--info").alert("hide");
				if (window.damFileUploadSucces) {
					//atleast one file is uploaded.
					window.damFileUploadSucces = 0;//reset
					var successNotificationMessage = Granite.I18n.get("Successfully Uploaded");
					var successNotification = {
							content: successNotificationMessage,
							type: Granite.UI.Notification.TYPES.success,
							heading: "",
							className: "notification-alert--absolute",
							closable: true}; 
					showNotificationSlider(successNotification, 3000);
				}
			}
			$(document).one("foundation-contentloaded", detectDuplicateAssets);
			cleanup(event);
			return true;
		} else {
			return false;
		}

	}
	
	function showDuplicates(event, duplicates) {
		// create modal with the data in duplicates
		var xssName = _g.XSS.getXSSValue(duplicates[0]["fileName"]);
		var firstDuplicate = "<b>"+ xssName +"</b>";
		var foundationContent = $(".foundation-content-path");
		var foundationContentType = $(".foundation-content-path").data("foundationContentType");
		var assetExistsMessage;
		var description;
		if (foundationContentType === "folder") {
			assetExistsMessage = Granite.I18n.get("An asset named {0} already exists in this location", firstDuplicate);
			description = Granite.I18n.get("Click 'Create Version' to create the version of the asset or 'Replace' to replace the asset or 'Keep Both' to keep both assets or 'X' to cancel the upload.");
		} else if (foundationContentType === "asset") {
			assetExistsMessage = Granite.I18n.get("A rendition named {0} already exists in this location", firstDuplicate);
			description = Granite.I18n.get("Click 'Replace' to replace the rendition or 'Keep Both' to keep both renditions or 'X' to cancel the upload."); 
		}
		
		var applyToAllMessage = Granite.I18n.get("Apply to all");
		var userSelection = "";
		var content = assetExistsMessage + "<br><br>" +  description;
		var applyToAll = "<label class=\"coral-Checkbox coral-Form-field\"><input class=\"coral-Checkbox-input\" type=\"checkbox\">"
		+ "<span class=\"coral-Checkbox-checkmark\"></span><span class=\"coral-Checkbox-description\">"
		+ applyToAllMessage + "</span></label>";
		content = "<p>" + content + "</p>";
		if (duplicates.length > 1) {
			content+= applyToAll;
		}
		
		if ($("#nameConflict").length === 0) {
	        var insertModal = $("<div>", {"class": "coral-Modal", "id": "nameConflict", "style": "width:30rem"}).hide().html(MODAL_HTML);
			$(document.body).append(insertModal);
		}
		$("#nameConflict").off("beforehide");
		$("#nameConflict").on("beforehide", function(evt) {
			if (userSelection === "") {
				// dismissed by 'Esc' or data-dismiss button
				cleanup(event);
			}
		});
		
		var buttons = [];
		if (foundationContentType === "folder") {
			buttons.push({
				label : Granite.I18n.get('Create Version'),
				className : "coral-Button coral-Button--primary",
				click : function(evt) {
					userSelection = "createversion";
					this.hide();
					createVersion(event, duplicates);
				}
			});
		}
		buttons.push({
			label : Granite.I18n.get('Replace'),
			className : "coral-Button coral-Button--primary",
			click : function(evt) {
				userSelection = "replace";
				this.hide();
				replaceAsset(event, duplicates);					
			}
		});
		buttons.push({
			label : Granite.I18n.get('Keep Both'),
			className : "coral-Button coral-Button--primary",
			click : function(evt) {
				userSelection = "keepBoth";
				this.hide();
				keepBothAssets(event, duplicates);
			}
		});
		var modal = new CUI.Modal({
			element : '#nameConflict',
			heading : Granite.I18n.get('Name Conflict'),
			content : content,
			buttons : buttons
		});
	}

	function detectDuplicateAssets() {

		if (duplicateAssets.length > 0) {
			var firstDuplicate = duplicateAssets[0];			
			var uploadedAsset = "<b>" + _g.XSS.getXSSValue(firstDuplicate[0]) + "</b>";
			var duplicatedBy = firstDuplicate[1].split(":");
			var duplicatedByMess = "<br><br>";

			for ( var i = 0; i < duplicatedBy.length; i++) {
				duplicatedByMess += _g.XSS.getXSSValue(duplicatedBy[i]) + "<br>"
			}

			var assetExistsMessage = Granite.I18n
					.get(
							"The asset uploaded {0} already exists in these location(s):",
							uploadedAsset);
			assetExistsMessage += duplicatedByMess;
			var description = Granite.I18n
					.get("Click 'Keep It' to keep or 'Delete' to delete the the uploaded asset.");

			var applyToAllMessage = Granite.I18n.get("Apply to all");
			var userSelection = "";
			var content = assetExistsMessage + "<br><br>" + description;
			var applyToAll = "<label><input type=\"checkbox\"><span></span></label>"
					+ applyToAllMessage;
			content = "<p>" + content + "</p>";
			if (duplicateAssets.length > 1) {
				content += applyToAll;
			}
			if ($("#duplicateAssets").length === 0) {
				var insertModal = $("<div>", {"class": "coral-Modal", "id": "duplicateAssets", "style": "width:30rem"}).hide().html(MODAL_HTML);
				$(document.body).append(insertModal);
			}
			$("#duplicateAssets").off("beforehide");
			$("#duplicateAssets").on("beforehide", function(evt) {
				if (userSelection === "") {
					// dismissed by 'Esc' or data-dismiss button - uploaded
					// asset remains
					cleanupAfterDeletingDuplicates();
				}
			});

			var buttons = [];
			buttons.push({
				label : Granite.I18n.get('Keep It'),
				className : "coral-Button coral-Button--primary",
				click : function() {
					userSelection = "keep";
					this.hide();
					keepUploadedAssets();
				}
			});
			buttons.push({
				label : Granite.I18n.get('Delete'),
				className : "coral-Button coral-Button--primary",
				click : function() {
					userSelection = "delete";
					this.hide();
					deleteUploadedAssets();
				}
			});
			var modal = new CUI.Modal({
				element : '#duplicateAssets',
				heading : Granite.I18n.get('Duplicates Detected'),
				type : "notice",
				content : content,
				buttons : buttons
			});

		}
	}

	function deleteUploadedAssets() {
		var checked = $("#duplicateAssets input[type='checkbox']").prop(
				"checked");
		if (checked || duplicateAssets.length === 1) {
			var a = [];
			for ( var i = 0; i < duplicateAssets.length; i++) {
				a[i] = duplicateAssets[i][0];
			}
			deleteAssetsAfterUpload(a);
			cleanupAfterDeletingDuplicates();
		} else {
			var a = [];
			a[0] = duplicateAssets[0][0];
			deleteAssetsAfterUpload(a);
			// remove duplicates[0]
			duplicateAssets.splice(0, 1);
			detectDuplicateAssets();
		}
	}

	function keepUploadedAssets() {
		var checked = $("#duplicateAssets input[type='checkbox']").prop(
				"checked");
		if (checked || duplicateAssets.length === 1) {
			cleanupAfterDeletingDuplicates();
		} else {
			// remove duplicates[0]
			duplicateAssets.splice(0, 1);
			detectDuplicateAssets();
		}
	}

	function deleteAssetsAfterUpload(files) {
		// deletes the files from the server
		for ( var i = 0; i < files.length; i++) {
			var filePath = Granite.HTTP.externalize(files[i]);
			Granite.$.ajax({
				async : false,
				url : filePath,
				type : "POST",
				data : {
					":operation" : "delete"
				}
			});
		}
	}

	function cleanupAfterDeletingDuplicates() {
		duplicateAssets = [];
		var contentApi = $(".foundation-content").adaptTo(
				"foundation-content");
		contentApi.refresh();
	}

	function keepBothAssets(event, duplicates) {
	    var checked = $("#nameConflict input[type='checkbox']").prop("checked");
	    if (checked || duplicates.length === 1) {
	        autoResolveDuplicateFileNames(event, duplicates);
	        continueUpload(event);
	    } else {
	        autoResolveDuplicateFileNames(event, [duplicates[0]]);
	        //remove duplicates[0]
	        duplicates.splice(0, 1);
	        showDuplicates(event, duplicates);
	    }
	}

	function replaceAsset(event, duplicates) {
	    var checked = $("#nameConflict input[type='checkbox']").prop("checked");
	    if (checked || duplicates.length === 1) {
	        deleteDuplicatesBeforeUpload(duplicates);
	        continueUpload(event);
	    } else {
	        deleteDuplicatesBeforeUpload([duplicates[0]]);
	        //remove duplicates[0]
	        duplicates.splice(0, 1);
	        showDuplicates(event, duplicates);
	    }
	}

	function createVersion(event, duplicates) {
	    var checked = $("#nameConflict input[type='checkbox']").prop("checked");
	    if (checked || duplicates.length === 1) {
	        deleteChunks(duplicates);
	        continueUpload(event);
	    } else {
	        deleteChunks(duplicates);
	        //remove duplicates[0]
	        duplicates.splice(0, 1);
	        showDuplicates(event, duplicates);
	    }
	}

	function autoResolveDuplicateFileNames(event, duplicates) {
	    //sequential search will be sufficient as duplicates and fileList are parallel
	    var duplicatesIndex = 0;
	    for (var i = 0; i < event.fileUpload.list.length && duplicatesIndex < duplicates.length; i++) {
	        if (duplicates[duplicatesIndex].fileName === event.fileUpload.list[i].fileName) {
	            event.fileUpload.uploadQueue[i].fileName = resolveFileName(duplicates[duplicatesIndex].fileName, window.damDirectoryJson);
	            if (!event.fileUpload.options.useHTML5 && event.fileUpload.options.uploadUrl.indexOf(".createasset.html") == -1) {
	                //for non-html5 sling post servlet uploads, change the input element name attribute withe above resolvedName
	                event.fileUpload.inputElement.attr("name", event.fileUpload.uploadQueue[i].fileName);
	            }
	            duplicatesIndex++;
	        }
	    }
	}

	function resolveFileName(fileName, directoryJson) {
	    var fn = fileName;
	    var fileExtn = "";
	    if (fileName.indexOf(".") !== -1) {
	        fn = fileName.substr(0, fileName.lastIndexOf("."));
	        fileExtn = fileName.substr(fileName.lastIndexOf(".") + 1);
	    }
	    var counter = 1;
	    var tempFn;
	    do {
	        tempFn = fn + counter;
	        counter++;
	    } while (directoryJson[UNorm.normalize("NFC",tempFn) + "." + fileExtn]);
	    return tempFn + "." + fileExtn;
	}
	
	function getDuplicates(uploadFiles) {
		var duplicates = [];
		var duplicateCount = 0;
		var jsonPath = "";
		var jsonResult;
		var foundationContent = $(".foundation-content-path");
		var foundationContentType = foundationContent.data("foundationContentType");
		var resourcePath = encodeURIComponent(getContentPath()).replace(/%2F/g,"/");
		if (foundationContentType  === "folder") {
			jsonPath = resourcePath + ".1.json?ch_ck = " + Date.now();
		} else if (foundationContentType === "asset") {
			jsonPath = resourcePath + "/_jcr_content/renditions.1.json?ch_ck = " + Date.now();
		}
		jsonPath = Granite.HTTP.externalize(jsonPath);
		var result = Granite.$.ajax({
			type : "GET",
			async : false,
			url : jsonPath
		});
		if (result.status === 200) {
			jsonResult = JSON.parse(result.responseText);
			for ( var i = 0; i < uploadFiles.length; i++) {
				if (jsonResult[UNorm.normalize("NFC", uploadFiles[i]["fileName"])]) {
					duplicates[duplicateCount] = uploadFiles[i];
					duplicateCount++;
				}
			}
		}
		window.damDirectoryJson = jsonResult;
		return duplicates;
	}

	function getContentPath() {
	    var contentPath;
	    var isSelectionMode = $(".foundation-selections-item").length || $(".cq-damadmin-admin-childpages").hasClass("mode-selection");
	    if (isSelectionMode) {
	        contentPath = $(".foundation-selections-item").data("path");
	        // CQ-24459: Assets should be uploaded to folders only and not to assets.
	        if ($(".foundation-selections-item").data("type") == "asset") {
	            // Upload to the parent folder
	            contentPath = contentPath.substr(0, contentPath.lastIndexOf('/'));
	        }
	    } else {
	        contentPath = $(".foundation-content-path").data("foundationContentPath");
	    }
	    return contentPath;
	}

	function deleteDuplicatesBeforeUpload(files) {
		// deletes the files from the server
		var foundationContent = $(".foundation-content-path");
		var foundationContentPath = getContentPath();
		var foundationContentType = foundationContent.data("foundationContentType");
		if (foundationContentType === "asset") {
			foundationContentPath += "/_jcr_content/renditions";
		}
		foundationContentPath = Granite.HTTP.externalize(foundationContentPath);
		for ( var i = 0; i < files.length; i++) {
			var filePath = foundationContentPath + "/" + UNorm.normalize("NFC",files[i]["fileName"]);
			Granite.$.ajax({
				async : false,
				url : filePath,
				type : "POST",
				data : {
					":operation" : "delete"
				}
			});
		}
	}

    function deleteChunks(files) {
        // deletes the files from the server
        var foundationContent = $(".foundation-content-path");
        var foundationContentPath = getContentPath();
        var foundationContentType = foundationContent.data("foundationContentType");
        if (foundationContentType === "asset") {
            foundationContentPath += "/_jcr_content/renditions";
        }
        foundationContentPath = Granite.HTTP.externalize(foundationContentPath);
        for (var i = 0; i < files.length; i++) {
            var filePath = foundationContentPath + "/" + UNorm.normalize("NFC", files[i]["fileName"]);
            if (typeof(CUIFileUpload.canChunkedUpload) === "function"
                && CUIFileUpload.canChunkedUpload(files[i]) === true) {
                    CUIFileUpload.deleteChunkedUpload(filePath);
            }
        }
    }

    function fileChunkedUploadQuerySuccess(event) {
        try {
            var json = JSON.parse(event.originalEvent.target.responseText);
            var bytesUploaded = json["jcr:content"]["sling:length"];
            if (bytesUploaded) {
                event.fileUpload.resumeChunkedUpload(event.item, bytesUploaded);
            } else {
                event.message = "No chunk upload found."
                fileUploadError(event);
            }
        } catch (err) {
            event.message = "Error in query chunked upload."
            fileUploadError(event);
        }
    }

    function fileChunkedUploadQueryError(event) {
        fileChunkedUploadError(event);
    }

    function fileChunkedUploadDeleteSuccess(event) {
        // do nothing
    }

    function fileChunkedUploadDeleteError(event) {
        fileUploadError(event);
    }

    function fileChunkedUploadSuccess(event) {
        var progress = (event.offset + event.chunk.size) / event.item.file.size * 100;
        $('.coral-Progress-status',
            $(document.getElementById("progress" + event.item.fileName))).css('width', progress + '%');
        //hide cancel button upon 100%, because server still takes
        //some time to finish after uploading 100%
        if (progress === 100) {
            $('.cancel', $(document.getElementById("progress" + event.item.fileName))).hide();
            $('.coral-Icon--playCircle',
                $(document.getElementById("progress" + event.item.fileName))).hide();
            $('.coral-Icon--pauseCircle',
                $(document.getElementById("progress" + event.item.fileName))).hide();
        }
    }

    function fileChunkedUploadCanceled(event) {
        changeIconPauseToPlay(event.item);
    }

    function fileChunkedUploadError(event) {
        changeIconPauseToPlay(event.item);
        if( manualPause === false) {
            // retry after 5 seconds
            chunkRetryHanlder = setTimeout( function() { resumeChunkUpload(event.item); }, 5000);
        }
    }

    function fileChunkedUploadStart(event) {
        changeIconPlayToPause(event.item);
    }

	function showRejectedFiles(event) {
		var rejectedFiles = event.fileUpload.rejectedFiles;
		var userSelection = "";
		var message = Granite.I18n.get("Following file(s) are violating the size constraint");
		if ($("#rejectedFiles").length === 0) {
			var insertModal = $("<div>", {"class": "coral-Modal", "id": "rejectedFiles", "style": "width:30rem"}).hide().html(MODAL_HTML);
			$(document.body).append(insertModal);
		}
		$("#rejectedFiles").off("beforehide");
		$("#rejectedFiles").on("beforehide", function(evt) {
			if (userSelection === "") {
				// dismissed by 'Esc' or data-dismiss button
				cleanup(event);
			}
		});
		var label = event.fileUpload.list && event.fileUpload.list.length > 0 ? Granite.I18n.get("Continue")
				: Granite.I18n.get("OK");
		var content = "";
		for ( var i = 0; i < rejectedFiles.length; i++) {
			content = content + rejectedFiles[i]["fileName"] + "<br>";
		}
		content = message + "<br>" + content;
		var modal = new CUI.Modal({
			element : '#rejectedFiles',
			heading : Granite.I18n.get('Rejected Files'),
			type : "error",
			content : content,
			buttons : [ {
				label : label,
				className : "coral-Button coral-Button--primary",
				click : function(evt) {
					userSelection = "continue";
					this.hide();
					event.fileUpload.rejectedFiles = [];
					proceedUpload(event);
				}
			} ]
		});
	}
	function continueUpload(event) {
	    //[CQ-7061] fileuploadprogress event was not firing because fileUpload.$element is caching a jquery element
	    //representing a stale DOM tree. The contentApi.refresh() manipulates the DOM after each file upload success event
	    //and hence invalidates the $element. $element is used while triggering fileuploadprogress event which bubbles up
	    //to the #document node. This up-traversal is via $element.parentNode recursively and hence, the need to refresh the
	    //$element jquery object to map to the current DOM at real time.
	    //Ideally should be fixed in CoralUI, where instead of caching the jquery objects, the selectors should be stored.
	    //Need to consider the performance impact of this fix though because referring to $element every time will cause a
	    //jquery selector match.
	    event.fileUpload.$element = $(event.currentTarget);
		var showProgress = event.fileUpload.inputElement.data('showProgress');
		var showNotifications = event.fileUpload.inputElement.data('showNotifications');
		if (showProgress) {
			var uploadCards = [];
			var columnToInsert,columnView;
			var columnLayout = isColumnLayout();
			if (columnLayout) {
				columnToInsert =$(".foundation-selections-item").length ? $(".cq-damadmin-admin-childpages .coral-ColumnView-column.is-active + .coral-ColumnView-column"):
					$(".cq-damadmin-admin-childpages .coral-ColumnView-column.is-active");
				if (!columnToInsert.length) {
				    columnToInsert = $(".cq-damadmin-admin-childpages .coral-ColumnView-column");
				}
				columnView =  $('.cq-damadmin-admin-childpages').data('foundation-layout-columns.internal.ColumnView');
				//update the uploadUrl to current selection
				//CQ-24849 Extract the content path from the current upload url TODO: think of a better way to achieve this.
				var contextPath = event.fileUpload.options.uploadUrl.substr(0, event.fileUpload.options.uploadUrl.indexOf("/content/dam"));
				event.fileUpload.options.uploadUrl = contextPath + getContentPath() + ".createasset.html";
			}
			for ( var i = 0; i < event.fileUpload.list.length; i++) {
				// create the upload card
				var uploadCard = createUploadCard(event.fileUpload.list[i].fileName);
				//add the cancel event handler
				var fileUpload = event.fileUpload;
				var item = fileUpload.list[i];
										
				//my custom code to look for file allowed at that location
				var url = location.href;
                var fileUploadLocation = getContentPath();
				var  extension = item.fileName.substr(item.fileName.lastIndexOf("."));
				var filesize = item.fileSize;
				var servletURL = "/bin/services/damwhitelistcheck";

				$.ajax({
					url: servletURL,
					dataType: "json",
					type: 'GET',
					async: false,
					data: {
                        "filePath" : fileUploadLocation,
                        "extension": extension,
                        "fileSize":filesize
                        
                    },
					success: function(data){
                        if(data.Allowed == "false"){
                            var errorMessage = Granite.I18n.get("DAMAssetWarningMessage");
                            var content = errorMessage + "<br>" + event.item.fileName;
                            var buttonLabel = Granite.I18n.get("OK");
                            if ($("#uploadError").length === 0) {
                                var insertModal = $("<div>", {"class": "coral-Modal", "id": "uploadError", "style": "width:20rem"}).hide().html(MODAL_HTML);
                                $(document.body).append(insertModal);
                            }
                            var modal = new CUI.Modal({
                                element : '#uploadError',
                                heading : Granite.I18n.get('Error'),
                                type : "error",
                                content : content,
                                buttons : [ {
                                    label : buttonLabel,
                                    className : 'coral-Button coral-Button--primary',
                                    click : function(evt) {
                                        this.hide();
                                    }
                                } ]
                            });
                        }
					}
				});

				//maitain item in fileObjects with its name as the key
				fileObjects[item.fileName] = item;
				if (columnLayout) {
					columnView.addItem(uploadCard, columnToInsert, 0);
				} else {
					uploadCards.push(uploadCard);
				}
			}
			if (!columnLayout) {
				if ($(event.fileUpload.$element).hasClass("cq-emptycontent-wrapper")) {
				    event.fileUpload.$element = $("div.endor-ActionBar-left span.cq-damadmin-admin-actions-asset-upload-activator");
				}
				CUI.CardView.get($(".foundation-collection")).prepend(uploadCards);
			}

		}
		if (showNotifications) {
			var progressNotificationMessage = Granite.I18n.get("Uploading..");
			var progressNotification = {
					content: progressNotificationMessage,
					type: Granite.UI.Notification.TYPES.info,
					heading: "",
					className: "notification-alert--absolute",
					closable: true}; 
			showNotificationSlider(progressNotification, 5184000/**very large value*/);
		}
        for (var i = 0; i < event.fileUpload.list.length; i++) {
            if (typeof(event.fileUpload.canChunkedUpload) === "function"
                && event.fileUpload.canChunkedUpload(event.fileUpload.list[i]) === true) {
            event.fileUpload.startChunkedUpload(event.fileUpload.list[i]);
            } else {
                event.fileUpload.uploadFile(event.fileUpload.list[i]);
            }
        }
		window.damTotalFilesForUpload = window.damTotalFilesForUpload || 0;
		window.damTotalFilesForUpload = window.damTotalFilesForUpload + event.fileUpload.list.length;
		event.fileUpload.list = [];
	}
	
	function showNotificationSlider(notification, duration) {
		var $container = $(".endor-Page-content.endor-Panel").eq(0);
		var $toolbar = $container.find(".endor-Panel-header.endor-BlackBar");
		var progressNotificationSlider= new Granite.UI.NotificationSlider($container, $toolbar, duration);
		progressNotificationSlider.notify(notification);
	}

    function cleanUpChunkedUpload(item) {
        var contextPath = CUIFileUpload.options.uploadUrl.substr(0, CUIFileUpload.options.uploadUrl.indexOf("/content/dam"));
        var filePath = contextPath + getContentPath() + "/" + UNorm.normalize("NFC", item.fileName);
        var jsonPath = filePath + "/_jcr_content/renditions/original.1.json?ch_ck = " + Date.now();
        jsonPath = Granite.HTTP.externalize(jsonPath);
        var result = Granite.$.ajax({
            type : "GET",
            async : false,
            url : jsonPath
        });
        if (result.status === 200) {
            deleteChunks([item]);
        } else {
            deleteAssetsAfterUpload([filePath]);
        }
    }
	
	function createUploadCard(name) {
		var xssName = _g.XSS.getXSSValue(name);
		var uploadCard, div, progress, progressBar, status, cancel, label, title, uploading, chunkUploadPause, chunkUploadResume;
		if (isColumnLayout()) {
			uploadCard = $("<a id=\"progress"
					+xssName
					+"\" class=\"foundation-collection-item card-asset uploading coral-ColumnView-item\" data-timeline = \"false\">");
			var uploadIcon = $("<div class=\"coral-ColumnView-icon\">" +
					"<i class=\"coral-Icon coral-Icon--upload coral-Icon--sizeM\"></i> </div>");
			title = $("<div class=\"coral-ColumnView-label foundation-collection-item-title\" itemprop=\"title\">" + xssName + "</div>");
			progress = $("<div class=\'coral-Progress\' ></div>");
			progressBar = $("<div class=\'coral-Progress-bar\' style=\"display:none\"></div>");
			status = $("<div class=\'coral-Progress-status\' style=\"width:0%\"></div>");
			cancel = $("<i class=\"cancel\" style=\"display:none\"></i>");
			chunkUploadPause = $("<i class=\'coral-Icon coral-Icon--sizeM coral-Icon--pauseCircle\' style=\"display:none\"></i>");
			chunkUploadResume = $("<i class=\'coral-Icon coral-Icon--sizeM coral-Icon--playCircle\' style=\"display:none\"></i>");
			progressBar.append(status);
			progress.append(progressBar);
			progress.append(cancel);
			progress.append(chunkUploadPause);
			progress.append(chunkUploadResume);
			uploadCard.append(uploadIcon);
			uploadCard.append(title);
			uploadCard.append(progress);

		} else {
			uploadCard = $("<article id=\"progress"
					+ xssName
					+ "\" class=\'card-asset uploading\'><i class=\'select\'></i></article>");
			div = $("<div class=\'card\'></div>");
			progress = $("<div class=\'coral-Progress\' ></div>");
			progressBar = $("<div class=\'coral-Progress-bar\' style=\"display:none\"></div>");
			status = $("<div class=\'coral-Progress-status\' style=\"width:0%\"></div>");
			cancel = $("<i class=\'cancel\' style=\"display:none\"></i>");
			label = $("<div class=\'label\'></div>");
			title = $("<h4>" + xssName + "</h4>");
			uploading = $("<p>"+ Granite.I18n.get("Uploading") +"&hellip;</p>");
			chunkUploadPause = $("<i class=\"coral-Icon coral-Icon--sizeM coral-Icon--pauseCircle\" style=\"display:none;\"></i>");
			chunkUploadResume = $("<i class=\"coral-Icon coral-Icon--sizeM coral-Icon--playCircle\" style=\"display:none;\"></i>");
			label.append(title);
			label.append(uploading);
			progress.append(progressBar);
			progressBar.append(status);
			progress.append(cancel);
			progress.append(chunkUploadPause);
			progress.append(chunkUploadResume);
			div.append(progress);
			div.append(label);
			uploadCard.append(div);
		}

		return uploadCard;
	}

    function changeIconPauseToPlay(item) {
        var $el = $(document.getElementById("progress" + item.fileName));
        $('.coral-Icon--pauseCircle', $el).hide();
        $('.coral-Icon--playCircle', $el).show();
        $('.coral-Progress-status', $el).css('background', '#FF0000');
    }

    function changeIconPlayToPause(item){
        var $el = $(document.getElementById("progress" + item.fileName));
        $(".coral-Progress-bar", $el).addClass("small");
        $('.coral-Icon--playCircle', $el).hide();
        $('.coral-Icon--pauseCircle', $el).show();
        $('.coral-Progress-status', $el).css('background','#2480cc');
    }

	function isColumnLayout() {
		var $coll = $(".cq-damadmin-admin-childpages");
		var layoutConfig = $coll.data("foundationLayout");
		return layoutConfig && (layoutConfig.name === "foundation-layout-columns");
	}

	function proceedUpload(event) {
		if (event.fileUpload.list && event.fileUpload.list.length) {
			// add browser warning for the refresh
			window.onbeforeunload = closeBrowserWarning;
			normalizeWhitespaces(event);
			// get if any duplicate files are being uploaded
			var duplicates = getDuplicates(event.fileUpload.list);
			if (duplicates && duplicates.length) {
				showDuplicates(event, duplicates);
			} else {
				continueUpload(event);
			}
		}
	}

    function normalizeWhitespaces(event) {
        var whitespaces =
           ["\u00A0", // NO-BREAK SPACE
            "\u1680", // OGHAM SPACE MARK
            "\u180E", // MONGOLIAN VOWEL SEPARATOR
            "\u2000", // EN QUAD
            "\u2001", // EM QUAD
            "\u2002", // EN SPACE
            "\u2003", // EM SPACE
            "\u2004", // THREE-PER-EM SPACE
            "\u2005", // FOUR-PER-EM SPACE
            "\u2006", // SIX-PER-EM SPACE
            "\u2007", // FIGURE SPACE
            "\u2008", // PUNCTUATION SPACE
            "\u2009", // THIN SPACE
            "\u200A", // HAIR SPACE
            "\u2028", // LINE SEPARATOR
            "\u2029", // PARAGRAPH SEPARATOR
            "\u202F", // NARROW NO-BREAK SPACE
            "\u205F", // MEDIUM MATHEMATICAL SPACE
            "\u3000"]; // IDEOGRAPHIC SPACE

        for ( var i = 0; i < event.fileUpload.list.length; i++) {
            for (var j = 0; j < whitespaces.length; j++) {
                event.fileUpload.list[i].fileName = event.fileUpload.list[i].fileName.replace(whitespaces[j]," ");
            }
            event.fileUpload.list[i].fileName = event.fileUpload.list[i].fileName.trim();
        }
    }

	function queueChanged(event) {
		if ($("span.coral-FileUpload input").attr("name") === "will_be_replaced") {
			$("span.coral-FileUpload input").attr("name", event.item.fileName);
		}

		// handle the no-children-banner
		var existingItems = $(".foundation-collection-item").length;
		var uploadingItems = $(".card-asset.uploading").length;
		var currentItem = 0;
		if (event.operation === "ADD") {
			currentItem = 1;
		}
	}

    //reset file input because cui starts file upload processing on *change* of input
    //this will make it work if selection repeats a file previously selected but cancelled for upload

    function resetFileInput(elem) {
    	elem.wrap('<form>').closest('form').get(0).reset();
		elem.unwrap();
    }

    /*
        Allow user to deselect/rename files before uploading via the fileSelected hook.
        Shows a dialog with the possible actions.
    */

    function fileSelected(event) {
    	    	
        //console.log('FILE SELECTED', event);
        CUIFileUpload = event.fileUpload;
        event.fileUpload.list = event.fileUpload.list || [];
        
        if (event.fileUpload.$element.find("input[type=file]").data("enablerename") === true ) {
            if (event.fileUpload.isDragOver == true) {
                var isValidUpload = true;
                var _ILLEGAL_FILENAME_CHARS = ['*', '/', ':', '[', '\\', ']', '|', '#', '%'];
                for (var i = 0; i < event.fileUpload.uploadQueue.length; i++) {
                var fileName = event.fileUpload.uploadQueue[i].fileName;				
                
                var strAsset = "assets.html";
				var str = location.href;
				var fileUploadLocation = str.substring(str.indexOf("assets.html")+strAsset.length);								
				var  extension = fileName.substr(fileName.lastIndexOf("."));
				var filesize=event.fileUpload.uploadQueue[i].fileSize;				
				var servletURL = "/bin/services/damwhitelistcheck";

				$.ajax({
					url: servletURL,
					dataType: "json",
					type: 'GET',
					async: false,
					data: {
                        "filePath" : fileUploadLocation,
                        "extension": extension,
						"fileSize":filesize
                    },
					success: function(data){
                        if(data.Allowed == "false"){
                            var errorMessage = Granite.I18n.get("DAMAssetWarningMessage");
                            var content = errorMessage + "<br>" + fileName;
                            var buttonLabel = Granite.I18n.get("OK");
                            if ($("#uploadError").length === 0) {
                                var insertModal = $("<div>", {"class": "coral-Modal", "id": "uploadError", "style": "width:20rem"}).hide().html(MODAL_HTML);
                                $(document.body).append(insertModal);
                            }
                            var modal = new CUI.Modal({
                                element : '#uploadError',
                                heading : Granite.I18n.get('Error'),
                                type : "error",
                                content : content,
                                buttons : [ {
                                    label : buttonLabel,
                                    className : 'coral-Button coral-Button--primary',
                                    click : function(evt) {
                                        this.hide();
                                    }
                                } ]
                            });
                        }
					}
				});
				
                isValidUpload = isValidUpload && !contains(fileName, _ILLEGAL_FILENAME_CHARS)
                } 
                
                if (isValidUpload) {
                    event.fileUpload.list.push(event.item);
                } else {
                	renameDialog(event);
                }	
            }
            else {
            	renameDialog(event);
            }
        }
        else {
            event.fileUpload.list.push(event.item);
        }

    }
    
    function renameDialog(event) {

        var _event = event;//allow closure access

        var label = Granite.I18n.get("Selected Item(s)");

        var modalDivIdSelector = "#renameSelected";

        //create the buttons at runtime because further upload logic depends on the _event object passed
        var btnArray = [];

        btnArray.push({
                    label: Granite.I18n.get('Upload'),
                    className: "coral-Button coral-Button--primary uploadBtn",
                    click: function (e) {
                        var isValidUpload = true;
                        //validate file names for illegal characters
                        var fileNameInputs = $(modalDivIdSelector).find('.coral-Modal-body').find("input");
                        fileNameInputs.each(function (index) {
                            //trigger the change event on the fileNameInput, as the change
                            //couldn't have been triggered while clicking on the Upload button
                            var $this = $(this);
                            $this.trigger("change");
                            isValidUpload = isValidUpload && validFileName($this);
                        });

                        fileNameInputs.promise().done(function() {
                            if(isValidUpload) {//check if all fileNames passed the validation test
                                //start uploading by populating fileUpload.list from uploadQueue
                                for (var i = 0; i < _event.fileUpload.uploadQueue.length; i++) {
                                    //CQ-20009 Add only those files which are not already in the upload queue
                                    if (fileObjects[_event.fileUpload.uploadQueue[i].fileName] == undefined ) {
                                       _event.fileUpload.list.push(_event.fileUpload.uploadQueue[i]);
                                    }
                                }
                                proceedUpload(_event);
                                e.dialog.$element.modal("hide");
                            }
                        });
                    }
                });

        btnArray.push({
                    label: Granite.I18n.get('Cancel'),
                    className: 'coral-Button',
                    click: function(e) {
                        this.hide();
                        cleanup(_event);
                    }
                });

        //create a modal dialog to show options for renaming selected file(s)
        if ($(modalDivIdSelector).length === 0) {
            var insertModal = $("<div>", {"class": "coral-Modal", "id": "renameSelected", "style": "width:20rem"}).hide().html(MODAL_HTML);
            $(document.body).append(insertModal);

        }

        var modal = $(modalDivIdSelector).data("modal");
        if(modal) {//re-use the previously created modal dialog
            modal.options.buttons = btnArray;
            modal.applyOptions();
            modal.$element.find(".uploadBtn").removeAttr("disabled");
            modal.set({ visible: true });
        }
        else {//create a modal dialog just once per file upload irrespective of how many files are selected
            modal =
                new CUI.Modal({
                    element: '#renameSelected',
                    heading: Granite.I18n.get('Upload'),
                    type: "default",
                    buttons: btnArray
                });
        }

        //construct dialog body based on file(s) selected
        var $modal = $(modalDivIdSelector).find('.coral-Modal-body');
        $modal.html("");
        $modal.append(label);
        for (var i = 0; i < _event.fileUpload.uploadQueue.length; i++) {
            var selection = _event.fileUpload.uploadQueue[i];
            //CQ-20009 Display only those files which are not already in the upload queue
            if (fileObjects[selection.fileName] == undefined) {
                $modal.append("<div id=\"selection_" + i + "\" ></div>");
                var $div =  $modal.find("#selection_" + i);
                $div.append("<input type=\"text\" class= \"coral-Textfield\" value=\"" +  _g.XSS.getXSSValue(selection.fileName) + "\" style=\"width:80%\"></input>");
                $div.append("<button class=\"coral-Button coral-Button--square coral-Button--quiet close removeSelection\">" +
                        "<i class=\"coral-Icon coral-Icon--close coral-Icon--sizeXS\"></i></button>");
            }
        }

        //bind event handler for removing a file from selection
        //0.remove from upload queue
        //1.remove selectedFile input and X button from UI
        //2.disable upload button if uploadQueue is empty
        $modal.find(".removeSelection").fipo('tap', 'click', function (e) {

            var closeButton = $(e.target);
            var queueId = parseInt(closeButton.closest("div").attr("id").substr("selection_".length));
            var removedItem = _event.fileUpload.uploadQueue[queueId];

            _event.fileUpload.uploadQueue.splice(queueId, 1);

            $modal.find(".removeSelection").each(function() {
                var currentQueueId = parseInt($(this).parent().attr("id").substr("selection_".length));
                if(currentQueueId > queueId) {
                    $(this).parent().attr("id", "selection_" + (currentQueueId-1));
                }
            });

            closeButton.closest("div").remove();

            if (_event.fileUpload.uploadQueue.length == 0) {
                modal.$element.find(".uploadBtn").attr("disabled", "disabled");
                modal.hide();
                cleanup(_event);
            }
        });

        $modal.find("input").on("keypress", function(event) {
            var code = event.charCode;
            var restrictedCharCodes = [42, 47, 58, 91, 92, 93, 124, 35];
            if ($.inArray(code, restrictedCharCodes) > -1) {
                event.preventDefault();
            }
        });

        //bind event handler for change in filename
        //0.update filename in uploadQueue
        $modal.find("input").change(function (e) {

            var fileNameInput = $(e.target);
            if(!validFileName(fileNameInput)) {
                e.preventDefault();
                return false;
            }
            else {

            }
            var queueId = parseInt(fileNameInput.parent().attr("id").substr("selection_".length));
            var changedItem = _event.fileUpload.uploadQueue[queueId];

            changedItem.fileName = fileNameInput.val();
        });
    
    }

    function validFileName(fileNameInput) {
        var _ILLEGAL_FILENAME_CHARS = ['*', '/', ':', '[', '\\', ']', '|', '#', '%'];
        var fileName = fileNameInput.val();
        hideError(fileNameInput);
        if(contains(fileName, _ILLEGAL_FILENAME_CHARS)) {
            showError(fileNameInput, Granite.I18n.get("Characters {0} are not allowed in the file name", _ILLEGAL_FILENAME_CHARS.join(', ')));
            return false;
        }
        return true;
    }

    function contains(str, chars) {
        for(var i=0; i<chars.length; i++) {
            if(str.indexOf(chars[i]) > -1) {
				return true;
            }
        }
        return false;
    }

    function showError($ele, msg) {
        $ele.addClass("is-invalid");
        $ele.parent().append("<div class=\"coral-Tooltip coral-Tooltip--error hidden coral-Tooltip--positionBelow\">" + msg + "</div>");
    }

    function hideError($ele) {
        $ele.removeClass("is-invalid");
        $ele.parent().find("div.coral-Tooltip--error").remove();
    }

	function fileRejected(event) {
		event.fileUpload.rejectedFiles = event.fileUpload.rejectedFiles || [];
		event.fileUpload.rejectedFiles.push(event.item);
	}

	function fileListProcessed(event) {
		if (event.fileUpload.rejectedFiles
				&& event.fileUpload.rejectedFiles.length) {
			showRejectedFiles(event);
		} else {
			proceedUpload(event);
		}
	}

	function fileUploadLoad(event) {
		var request = _g.shared.HTTP.buildPostResponseFromHTML(event.content);
		event.fileUpload._internalOnUploadLoad(event, event.item,
				request.headers['Status'], request);
	}
	function fileUploadCanceled(event) {
        //remove the entry of this item in fileObjects
        delete fileObjects[event.item.fileName];
		// hide the article
		// Using document.getElementById as direct jquery selector behaves erroneously for xss prone string
		$(document.getElementById("progress" + event.item.fileName)).hide();
		 //layout again
		 if (!isColumnLayout()) {
		     CUI.CardView.get($(".foundation-collection")).layout();
		 }
		 refresh(event);
	}
	function fileUploadStart(event) {
		// Using document.getElementById as direct jquery selector behaves erroneously for xss prone string
		$('.coral-Progress-bar', $(document.getElementById("progress" + event.item.fileName))).show();
		$('.cancel', $(document.getElementById("progress" + event.item.fileName))).show();
	}
	function fileUploadProgress(event) {
		// Using document.getElementById as direct jquery selector behaves erroneously for xss prone string
		var progress = event.originalEvent.loaded / event.originalEvent.total*100;
		$('.coral-Progress-status', $(document.getElementById("progress" + event.item.fileName))).css(
				'width', progress + '%');
		//hide cancel button upon 100%, because server still takes some time to finish after uploading 100%
		if (progress === 100) {
			$('.cancel', $(document.getElementById("progress" + event.item.fileName))).hide();	
		}
	}
	function fileUploadSuccess(event) {
		window.damFileUploadSucces = 1;
		//remove the entry of this item in fileObjects
		delete fileObjects[event.item.fileName];
		// refresh the content when all the files are uploaded
		if(!refresh(event)) {
			// Using document.getElementById as direct jquery selector behaves erroneously for xss prone string
			var asset = $(document.getElementById("progress" + event.item.fileName));
			var assetName = event.item.fileName;
			var xssName = _g.XSS.getXSSValue(assetName);
			asset.empty();
			var folderPath = getContentPath();
			if (folderPath.charAt(folderPath.length - 1) != '/') {
				folderPath = folderPath + "/";
			}
			var dataPath = folderPath + encodeURIComponent(assetName);
			dataPath = Granite.HTTP.externalize(dataPath);
			asset.attr('data-path', dataPath);
			asset.attr('data-type', 'asset');
			if (isColumnLayout()) {
				asset.attr("class", "foundation-collection-item coral-ColumnView-item");
				var thumbNail = $("<div class=\"coral-ColumnView-icon\"><img class=\"coral-ColumnView-thumbnail\" src=\"" + dataPath +".thumb.48.48.png?ck=1405668368000\" itemprop=\"thumbnail\"></div>");
				var label = $("<div class=\"coral-ColumnView-label foundation-collection-item-title\" itemprop=\"title\" title=\""+assetName+"\">"+ assetName + "</div>");
				asset.append(thumbNail);
				asset.append(label);
			} else {
				asset.attr('class', 'foundation-collection-item card-asset');
				asset.append($("<i class=\'select\'></i>"));
				var anchor = $("<a href=\'/assetdetails.html" + dataPath
						+ "\'></a>");
				var image = $("<span class=\'image \'></span>");
				var showGrid = $("<img class=\'show-grid\' src=\'" + dataPath
						+ ".thumb.319.319.png\' alt=\'" + assetName + "\'>");
				var showList = $("<img class=\'show-list\' src=\'" + dataPath
						+ ".thumb.319.319.png\' alt=\'" + assetName + "\'>");
				image.append(showGrid);
				image.append(showList);
				var label = $("<div class=\'label\'><h4>" + xssName
						+ "</h4></div>");
				anchor.append(image);
				anchor.append(label);
				asset.append(anchor);
			}

		}
	}
	
  function fileUploadError(event) {
        //remove the entry of this item in fileObjects
        delete fileObjects[event.item.fileName];

		if ((event.originalEvent && event.originalEvent.target.status && event.originalEvent.target.status == "409") || (event.message && event.message.headers && event.message.headers['Status'] == "409")) {
			if (event.originalEvent.target.status && event.originalEvent.target.status == "409") {
				var response = event.item.xhr.responseText;
				var title = $("#Path",response).text();
				var changeLog = $("#ChangeLog",response).text().trim();
			} else {
				//this condition is to support IE9 
				var title = event.message.headers['Path'];
				var changeLog = event.message.headers['ChangeLog'];
			}
			var indexOfDuplicates = changeLog.indexOf("duplicates")+ "duplicates(\"".length;
			var duplicates = changeLog.substring(indexOfDuplicates, changeLog.indexOf("\"",indexOfDuplicates));
			var arr = [title, duplicates];
			duplicateAssets.push(arr);
		} else {
			var errorMessage = Granite.I18n
					.get("Failed to upload the following file:");
			var content = errorMessage + "<br>" + event.item.fileName;
			if(event.message) {
				content += "<br>" + event.message;
			}
			var buttonLabel = Granite.I18n.get("OK");
			if ($("#uploadError").length === 0) {
				var insertModal = $("<div>", {"class": "coral-Modal", "id": "uploadError", "style": "width:20rem"}).hide().html(MODAL_HTML);
				$(document.body).append(insertModal);
			}
			var modal = new CUI.Modal({
				element : '#uploadError',
				heading : Granite.I18n.get('Error'),
				type : "error",
				content : content,
				buttons : [ {
					label : buttonLabel,
					className : 'coral-Button coral-Button--primary',
					click : function(evt) {
						this.hide();
					}
				} ]
			});
		}
		// refresh the content when all the files are uploaded
		refresh(event);

	}

	function dropZoneDragOver(event) {
		var message = Granite.I18n.get("Drag and drop to upload");
		var dragAndDropMessage = $('<div class=\"drag-drop-message\"><h1 > <span>{</span>' + message + '<span>}</span></h1></div>');
		$('.foundation-collection-container').overlayMask('show', dragAndDropMessage);
	}
	function dropZoneDragLeave(event) {
		$('.foundation-collection-container').overlayMask('hide');
	}
	function dropZoneDrop(event) {
        $('.foundation-collection-container').overlayMask('hide');
	}

    $(document).fipo("tap", "click", ".card-asset.uploading i.cancel", function(event) {
        var item = getFileObject($(event.target).closest("article,a").attr("id").replace("progress", ""));
        var contextPath = CUIFileUpload.options.uploadUrl.substr(0, CUIFileUpload.options.uploadUrl.indexOf("/content/dam"));
        if (typeof(CUIFileUpload.canChunkedUpload) === "function"
        && CUIFileUpload.canChunkedUpload(item) === true) {
            cleanUpChunkedUpload(item);
            CUIFileUpload.cancelChunkedUpload(item);
            var cancelEvent = {};
            cancelEvent.item = item;
            cancelEvent.fileUpload = CUIFileUpload;
            fileUploadCanceled(cancelEvent);
        } else if (item.xhr.readyState === 0) {
            var cancelEvent = {};
            cancelEvent.item = item;
            cancelEvent.fileUpload = CUIFileUpload;
            fileUploadCanceled(cancelEvent);
        } else {
            CUIFileUpload.cancelUpload(item);
        }

    });

    $(document).fipo("tap", "click", ".card-asset.uploading i.coral-Icon--pauseCircle", function(event) {
        var item = getFileObject($(event.target).closest("article,a").attr("id").replace("progress", ""));
        manualPause = true;
        pauseChunkUpload(item);
    });

    function pauseChunkUpload(item) {
        CUIFileUpload.cancelChunkedUpload(item);
    }

    $(document).fipo("tap", "click", ".card-asset.uploading i.coral-Icon--playCircle", function(event) {
        if (chunkRetryHanlder !== undefined) {
            clearTimeout(chunkRetryHanlder);
        }
        manualPause = false;
        var item = getFileObject($(event.target).closest("article,a").attr("id").replace("progress", ""));
        resumeChunkUpload(item);
    });

    function resumeChunkUpload(item) {
        changeIconPlayToPause(item);
        var url = getChunkInfoUrl(item, CUIFileUpload);
        CUIFileUpload.queryChunkedUpload(url, item);
    }

    function getChunkInfoUrl(item, fileupload) {
        var index = fileupload.options.uploadUrl.indexOf(".createasset.html");
        return fileupload.options.uploadUrl.substring(0, index) + "/" + item[fileupload.options.fileNameParameter] + ".3.json";
    }

    function getFileObject(fileName) {
        return fileObjects[fileName];
    }

	// re-attach all the fileupload events with the above handlers
	$(document).off("queuechanged", "span.coral-FileUpload");
	$(document).on("queuechanged", "span.coral-FileUpload", queueChanged);
	$(document).off("fileselected", "span.coral-FileUpload");
	$(document).on("fileselected", "span.coral-FileUpload", fileSelected);
	$(document).off("filerejected", "span.coral-FileUpload");
	$(document).on("filerejected", "span.coral-FileUpload", fileRejected);
	$(document).off("filelistprocessed", "span.coral-FileUpload");
	$(document).on("filelistprocessed", "span.coral-FileUpload", fileListProcessed);
	$(document).off("fileuploadload", "span.coral-FileUpload");
	$(document).on("fileuploadload", "span.coral-FileUpload", fileUploadLoad);
	$(document).off("fileuploadcanceled", "span.coral-FileUpload");
	$(document).on("fileuploadcanceled", "span.coral-FileUpload", fileUploadCanceled);
	$(document).off("fileuploadstart", "span.coral-FileUpload");
	$(document).on("fileuploadstart", "span.coral-FileUpload", fileUploadStart);
	$(document).off("fileuploadprogress", "span.coral-FileUpload");
	$(document).on("fileuploadprogress", "span.coral-FileUpload", fileUploadProgress);
	$(document).off("fileuploadsuccess", "span.coral-FileUpload");
	$(document).on("fileuploadsuccess", "span.coral-FileUpload", fileUploadSuccess);
	$(document).off("fileuploaderror", "span.coral-FileUpload");
	$(document).on("fileuploaderror", "span.coral-FileUpload", fileUploadError);
	$(document).off("filechunkeduploadquerysuccess", "span.coral-FileUpload");
	$(document).on("filechunkeduploadquerysuccess", "span.coral-FileUpload", fileChunkedUploadQuerySuccess);
	$(document).off("filechunkeduploadqueryerror", "span.coral-FileUpload");
	$(document).on("filechunkeduploadqueryerror", "span.coral-FileUpload", fileChunkedUploadQueryError);
	$(document).off("filechunkeduploaddeletesuccess", "span.coral-FileUpload");
	$(document).on("filechunkeduploaddeletesuccess", "span.coral-FileUpload", fileChunkedUploadDeleteSuccess);
	$(document).off("filechunkeduploaddeleteerror", "span.coral-FileUpload");
	$(document).on("filechunkeduploaddeleteerror", "span.coral-FileUpload", fileChunkedUploadDeleteError);
	$(document).off("filechunkeduploadsuccess", "span.coral-FileUpload");
	$(document).on("filechunkeduploadsuccess", "span.coral-FileUpload", fileChunkedUploadSuccess);
	$(document).off("filechunkeduploadcanceled", "span.coral-FileUpload");
	$(document).on("filechunkeduploadcanceled", "span.coral-FileUpload", fileChunkedUploadCanceled);
	$(document).off("filechunkeduploaderror", "span.coral-FileUpload");
	$(document).on("filechunkeduploaderror", "span.coral-FileUpload", fileChunkedUploadError);
	$(document).off("filechunkeduploadstart", "span.coral-FileUpload");
	$(document).on("filechunkeduploadstart", "span.coral-FileUpload", fileChunkedUploadStart);
	$(document).off("dropzonedragover", "span.coral-FileUpload");
	$(document).on("dropzonedragover", "span.coral-FileUpload", dropZoneDragOver);
	$(document).off("dropzonedrop", "span.coral-FileUpload");
	$(document).on("dropzonedrop", "span.coral-FileUpload", dropZoneDrop);
	$(document).off("dropzonedragleave", "span.coral-FileUpload");
	$(document).on("dropzonedragleave", "span.coral-FileUpload", dropZoneDragLeave);


})(document, Granite.$);;