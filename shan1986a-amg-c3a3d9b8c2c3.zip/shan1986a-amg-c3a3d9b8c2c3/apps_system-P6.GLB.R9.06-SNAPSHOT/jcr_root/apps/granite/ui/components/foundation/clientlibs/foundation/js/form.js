/*
  ADOBE CONFIDENTIAL

  Copyright 2012 Adobe Systems Incorporated
  All Rights Reserved.

  NOTICE:  All information contained herein is, and remains
  the property of Adobe Systems Incorporated and its suppliers,
  if any.  The intellectual and technical concepts contained
  herein are proprietary to Adobe Systems Incorporated and its
  suppliers and may be covered by U.S. and Foreign Patents,
  patents in process, and are protected by trade secret or copyright law.
  Dissemination of this information or reproduction of this material
  is strictly forbidden unless prior written permission is obtained
  from Adobe Systems Incorporated.
*/
(function(document, window, $, History) {
    "use strict";

    var iframeCounter = 0;

    $.ajaxTransport("foundation-form.internal.iframe", function(options) {
        var form = options.form;
        var iframe;

        return {
            send: function(_, callback) {
                iframeCounter++;

                var id = "foundation-form.internal.iframe." + iframeCounter;
                iframe = $('<iframe src="javascript:false;" style="display:none;" name="' + id + '" />');

                iframe.appendTo(document.body).one("load", function() {
                    var html = iframe.contents()[0].innerHTML;

                    callback(200, "success", {
                        "foundation-form.internal.iframe": html
                    });

                    form.removeAttr("target");

                    window.setTimeout(function() {
                        iframe.remove();
                    }, 0);
                });

                // use event capturing and capture the submit event at document level so that no handler is executed
                document.addEventListener("submit", function f(e) {
                    var form = $(e.target);

                    if (form.is("form.foundation-form") && form.data("foundation-form.internal.iframe.inprogress")) {
                        e.stopPropagation();
                        form.removeData("foundation-form.internal.iframe.inprogress");
                        document.removeEventListener("submit", f, true);
                    }
                }, true);

                form.attr("target", id);
                form.data("foundation-form.internal.iframe.inprogress", true);

                var event = document.createEvent("Event");
                event.initEvent("submit", true, true);

                form[0].dispatchEvent(event);
            },
            abort: function() {
                form.removeAttr("target").off(".foundation-form-internal-iframe");

                if (iframe) {
                    iframe.remove();
                }
            }
        };
    });

    var formDataSupport = window.FormData !== undefined;

    function resetField($el) {
        var api = $el.adaptTo("foundation-field");
        if (api) {
            api.reset();
        }
    }


    function fieldseprator(formserializer, enctype, action, method, isPost) {

        var tabSerialize = formserializer.split(/[&]/);
        var nodeProperties = "";
        var multiString = "";
        var singlefieldString = "";
        var multifieldString = "";
        var fristLabel = "";
        var parentNodeName = "";
        var parentNodeActionUrl = "";
        var propertyNames = "";
        var childNodActionUrl = "";
        var tabString = "";
        var nodeName = "";
        var multiFieldCount = "";
        var multiFieldNodeCount = "";
        var childNodeAddCount = "";
        var prevousNodeName = "";
        var nodeCounter = 0;
        for (var i = 0; i < tabSerialize.length; i++) {
            if (i == 0) {
                fristLabel = tabSerialize[0];
            } else { //ParentNodes Creation
                if ((tabSerialize[i].indexOf("customMultiFieldExistense")) > -1) {
                    multiString = tabSerialize[i].substring(0, tabSerialize[i].length - 1);
                    var tabFinder = multiString.split("~");
                    multiFieldCount = tabFinder.length;
                    for (var m = 0; m < tabFinder.length; m++) {
                        if (tabFinder[m].length > 0) {
                            if (m == 0) {
                                tabString = tabFinder[m].split("=");
                                nodeName = tabString[1].split("%24");
                            } else {
                                tabString = tabFinder[m];
                                nodeName = tabString.split("%24");
                            }
                            parentNodeName = parentNodeName + "#**@" + nodeName[0];
                            propertyNames = nodeName[1].split("%23");
                            multiFieldNodeCount = multiFieldNodeCount + "#**@" + propertyNames.length;
                            parentNodeActionUrl = action + "/" + nodeName[0];
                            $.ajax({
                                type: method,
                                url: parentNodeActionUrl,
                                contentType: enctype,
                                data: "",
                                cache: isPost || !$.browser.msie
                            });
                        }
                    }
                } else {
                    var tabFindersplit = multiString.split("~"); //MultiFieldExister String
                    for (var m = 0; m < tabFindersplit.length; m++) {
                        if (tabFindersplit[m].length > 0) {
                            if (m == 0) {
                                tabString = tabFindersplit[m].split("=");
                                nodeName = tabString[1].split("%24"); //nodeName of eachTab
                            } else {
                                tabString = tabFindersplit[m];
                                nodeName = tabString.split("%24");
                            }
                            var propertyNames = nodeName[1].split("%23"); //TabName
                            var nodeprop = tabSerialize[i].split("=");
                            for (var x = 0; x < propertyNames.length; x++) {
                                if (propertyNames[x] == nodeprop[0]) {
                                    multifieldString = multifieldString + tabSerialize[i] + "&";
                                    if ((propertyNames.length - 1) == x) {
                                        multifieldString = fristLabel + "&" + multifieldString.substring(0, multifieldString.length - 1);
                                        if (prevousNodeName == nodeName[0]) {
                                            nodeCounter++;
                                        } else {
                                            nodeCounter = 0;
                                        }
                                        childNodActionUrl = action + "/" + nodeName[0] + "/" + nodeCounter;
                                        prevousNodeName = nodeName[0];
                                        childNodeAddCount = childNodeAddCount + "#$@" + nodeName[0];
                                        $.ajax({
                                            type: method,
                                            url: childNodActionUrl,
                                            contentType: enctype,
                                            data: multifieldString,
                                            cache: isPost || !$.browser.msie
                                        });
                                        multifieldString = "";
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return multiString + "*#$*" + childNodeAddCount;
    }


    function checkBoxandRadioButtonChecker(form) {
        var fristLabel = "";
        var multiString = "";
        var tabString = "";
        var nodeName = "";
        var propertyNames = "";
        var returnString = "";
        var checkBoxUncheckCount = 0;
        var singleFields = "";
        var ifCount = 0;
        var singleFieldCheckBoxes = "";
        var secondLabel = "";
        for (var a = 0; a < form.find(":checkbox").length; a++) {
            //if(form.find(":checkbox")[j].checked == false){
            checkBoxUncheckCount++;
            //}
        }
        if (checkBoxUncheckCount > 0) {
            for (var j = 0; j < form.find(":checkbox").length; j++) {

                var checkBoxName = form.find(":checkbox")[j].name.replace("./", ".%2F");
              

                var tabSerialize = form.serialize().split(/[&]/);
                for (var i = 0; i < tabSerialize.length; i++) {
                    if (i == 0) {
                        fristLabel = tabSerialize[0];
                    } else {
                        if ((tabSerialize[i].indexOf("customMultiFieldExistense")) > -1) {
                            fristLabel = fristLabel + "&" + tabSerialize[1] + "&";
                            //secondLabel=tabSerialize[i]+"&";
                            multiString = tabSerialize[i].substring(0, tabSerialize[i].length - 1);
                            var tabFindersplit = multiString.split("~"); //MultiFieldExister String
                            for (var m = 0; m < tabFindersplit.length; m++) {
                                if (tabFindersplit[m].length > 0) {
                                    if (m == 0) {
                                        tabString = tabFindersplit[m].split("=");
                                        nodeName = tabString[1].split("%24"); //nodeName of eachTab
                                    } else {
                                        tabString = tabFindersplit[m];
                                        nodeName = tabString.split("%24");
                                    }
                                    propertyNames = nodeName[1].split("%23"); //TabName
                                    for (var x = 0; x < propertyNames.length; x++) {
                                        if (propertyNames[x] == checkBoxName) {
                                            if (form.find(":checkbox")[j].checked == false) {
                                                var checkboxCheck = form.serialize().split(propertyNames[x - 1]);
                                                for (var y = 0; y < checkboxCheck.length; y++) {
                                                    if (y > 1) {

                                                        var check = checkboxCheck[y].split(/[&]/);
                                                        var checkString = check[0] + "&" + checkBoxName + "=true";
                                                        if (checkboxCheck[y].indexOf(checkString) == -1) {
                                                            var addStrintg = propertyNames[x - 1] + check[0] + "&" + checkBoxName + "=false";
                                                            if (checkboxCheck[y].indexOf(addStrintg) == -1) {
                                                                var replaceString = checkboxCheck[y].replace(check[0], addStrintg);
                                                                if (returnString.indexOf(replaceString) == -1) {
                                                                    returnString = returnString + replaceString;
                                                                }
                                                            }
                                                        } else {
                                                            
                                                            if (returnString.indexOf(checkboxCheck[y]) == -1) {
                                                                returnString = returnString + propertyNames[x - 1] + checkboxCheck[y];
                                                            }
                                                           
                                                        }
                                                    }
                                                }

                                            }
                                        } else {
                                            if ((propertyNames.indexOf(checkBoxName)) == -1) {
                                                singleFieldCheckBoxes = singleFieldCheckBoxes + "$#" + checkBoxName;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
                ifCount++;
            }
            
            var totalString = "";
            if (returnString.length == 0) {
                totalString = checkBoccheckwithoutMultiField(form);
            } else {
                totalString = returnString;
                if (singleFieldCheckBoxes.length > 0) {
                    var uniqueList = removeDuplicates(singleFieldCheckBoxes, "$#");

                    for (var z = 0; z < uniqueList.length; z++) {
                        if (uniqueList[z].length > 0) {
                            
                            if ((totalString.indexOf(uniqueList[z])) == -1) {
                                totalString = totalString + uniqueList[z] + "=false&"
                            }
                        }
                    }
                }
                var beforesingle = form.serialize().split("~");
                var singleFields = beforesingle[1].split(propertyNames[0]);
                totalString = beforesingle[0] + "~" + singleFields[0] + totalString;

            }
        } else {
            totalString = form.serialize();
        }
        return totalString;
    }

    function checkBoccheckwithoutMultiField(form) {
        var totalString = form.serialize();
        for (var j = 0; j < form.find(":checkbox").length; j++) {
            var checkBoxName = form.find(":checkbox")[j].name.replace("./", ".%2F");
            if ((form.serialize().indexOf(checkBoxName)) == -1) {
                totalString = totalString + "&" + checkBoxName + "=false";
            }
        }
        return totalString;
    }


    function removeDuplicates(string, separator) {
        var arr = string.split(separator);
        var unique = [];
        $.each(arr, function(index, word) {
            if ($.inArray(word, unique) === -1)
                unique.push(word);
        });
        return unique;
    }

    function submitForm(form) {
        var enctype = form.prop("enctype");
        var method = form.prop("method");
        var action = form.prop("action");


        var isPost = method.toLowerCase() === "post";
        if (isPost && enctype === "multipart/form-data") {
            if (formDataSupport) {
                var formData = new FormData(form[0]);

                return $.ajax({
                    type: method,
                    url: action,
                    contentType: false,
                    mimeType: enctype,
                    processData: false,
                    data: formData,
                    cache: false
                });
            }

            if (form.find(":file").length > 0) {
                return $.ajax({
                    dataType: "foundation-form.internal.iframe",
                    type: method,
                    url: action,
                    contentType: enctype,
                    form: form,
                    cache: false
                });
            }
        }


        var totalString = checkBoxandRadioButtonChecker(form);
        
        if (((form.serialize()).indexOf("customMultiFieldExistense")) > -1) {
            //var totalString=form.serialize();
            
            var formserializer = fieldseprator(totalString, enctype, action, method, isPost);
           
            var serializer = formserializer.split("*#$*");
            var childNodeAddCount = serializer[1];
            var customMultiFieldExis = serializer[0];

            $.ajax({
                type: 'POST',
                url: '/bin/nodeDeleteServlet',
                data: 'deleteNodeCount=' + childNodeAddCount + '&fildXtype=CustomMultiField' + '&contentNodePath=' + action + '&customMultiFieldExist=' + customMultiFieldExis,
                success: function(msg) {
                    //display the data returned by the servlet
                }
            });

            return $.ajax({
                type: method,
                url: action,
                contentType: enctype,
                data: totalString,
                cache: isPost || !$.browser.msie
            });

        } else {
            return $.ajax({
                type: method,
                url: action,
                contentType: enctype,
                data: totalString,
                cache: isPost || !$.browser.msie
            });
        }
    }

    function handleResponse(form, xhr) {
        xhr
            .then(createSuccessHandler(form), createErrorHandler(form))
            .done(function() {
                form.trigger("foundation-form-submitted", [true, xhr]);
            })
            .fail(function() {
                form.trigger("foundation-form-submitted", [false, xhr]);
            });
    }

    function createSuccessHandler(form) {
        var url = form.data("redirect"); // TODO forget to namespace this attribute
        if (url) {
            return function() {
                $.ajax(url).always(createRenderOutput(form));
                // don't return promise from ajax (above statement)
                // even if the redirect fails, the form submission is still considered correct
            };
        } else {
            return createRenderOutput(form);
        }
    }

    function appendUrlQuery(url, queryString) {
        if (url.lastIndexOf("?") >= 0) {
            return url + "&" + queryString;
        }

        return url + "?" + queryString;
    }

    function createRenderOutput(form) {
        return function(html) {
            var panelSelector = form.data("foundationFormOutputReplace") || form.data("foundationFormOutputPush");

            if (!panelSelector) {
                return;
            }

            var p = $(panelSelector);

            var contentAPI = p.adaptTo("foundation-content");
            if (contentAPI) {
                var historyConfig = (function() {
                    if (History.enabled) {
                        var config = form.data("foundationFormHistory");
                        if (config) {
                            var url = config.url || config.useFormUrl ? appendUrlQuery(form.prop("action"), form.serialize()) : undefined;

                            return {
                                data: config.data,
                                title: config.title,
                                url: url
                            };
                        }
                    }
                })();

                if (form.data("foundationFormOutputReplace")) {
                    contentAPI.replace(html, historyConfig);
                } else {
                    contentAPI.push(html, historyConfig);
                }
            } else {
                p.html(html);
            }
        };
    }

    var ui = $(window).adaptTo("foundation-ui");

    function createErrorHandler(form) {
        return function(xhr, error, errorThrown) {
            if (form.data("foundationFormUi") === "none") {
                return;
            }

            var $html = $(xhr.responseText);

            if (error === "error") {
                if ($html.find(".foundation-form-response-status-code").length > 0) {
                    var title = $html.find(".foundation-form-response-title").next().html();
                    var message = $html.find(".foundation-form-response-description").next().html();

                    ui.alert(title, message, "error");
                    return;
                }
            }

            ui.alert(error, $html.find("title").text() || errorThrown, "error");
        };
    }

    $(document).on("foundation-form-submit-callback", "form.foundation-form", function(e, xhr) {
        handleResponse($(this), xhr);
    });

    $(document).on("reset", "form.foundation-form", function(e) {
        // Only reset foundation-field as standard form controls will be reset naturally during reset event
        $(this).adaptTo("foundation-form").reset(true);
    });

    $(document).on("submit", "form.foundation-form", function(e) {
        var form = $(this);
        
        if (form.data("foundationFormAjax")) {
            var historyConfig = form.data("foundationFormHistory");

            if (!History.enabled && (typeof(historyConfig) != 'undefined') && historyConfig.noSupportBehaviour === "disableAjax") { // the other option is "ignore", which is the default
                return;
            }

            e.preventDefault();

            if (!form.data("foundationFormDisable")) {

                var vanitytotalString = "";
                var tabSerialize = form.serialize().split(/[&]/);

                //carousel component validation
                if (form.serialize().indexOf("slideAsset") > -1) {
                    var carouselSlidesCounter = 0;
                    for (var n = 0; n < tabSerialize.length; n++) {
                        if (tabSerialize[n].indexOf("slideAsset") > -1 ){
							if(tabSerialize[n].indexOf("slideAssetOgg") == -1)
							{
							carouselSlidesCounter++;
							}

                        }
                    }
                    if (carouselSlidesCounter < 1) {
                        alert(CQ.I18n.getMessage("corouselErrorMessageMin"));
                    } else if (carouselSlidesCounter > 8) {
                        alert(CQ.I18n.getMessage("maxErrorMessage")+" 8");
                    } else {
                        handleResponse(form, submitForm(form));
                    }
                } //table columns component validation 
                else if (form.serialize().indexOf("columns") > -1) {
                    var columnCounter = 0;
                    for (var n = 0; n < tabSerialize.length; n++) {
                        if (tabSerialize[n].indexOf("columns") > -1) {
                            columnCounter++;
                        }
                    }
                    if (columnCounter < 2) {
                        alert(CQ.I18n.getMessage("error-message-tableColumns-min"));

                    } else if (columnCounter > 9) {
                        alert(CQ.I18n.getMessage("error-message-tableColumns-max"));
                    } else {
                        handleResponse(form, submitForm(form));
                    }


                } //Accordion Component Validation 
                else if (form.serialize().indexOf("accordion") > -1) {
                    var accordionCounter = 0;
                    for (var n = 0; n < tabSerialize.length; n++) {
                        if (tabSerialize[n].indexOf("label") > -1) {
                            accordionCounter++;
                        }
                    }
                    if (accordionCounter < 2) {
                        alert(CQ.I18n.getMessage("error-message-accordion"));

                    } else {
                        handleResponse(form, submitForm(form));
                    }

                } else if (form.serialize().indexOf("languageLink") > -1) { //footer component validation
                    var footerLanguageCounter = 0;
                    for (var n = 0; n < tabSerialize.length; n++) {
                        if (tabSerialize[n].indexOf("languageLink") > -1) {
                            footerLanguageCounter++;
                        }
                    }
                    if (footerLanguageCounter > 3) {
                        alert("Only 3 languages are supported.");
                    } else {
                        handleResponse(form, submitForm(form));
                    }
                } else if (form.serialize().indexOf("componentName=relatedlinks") > -1) { //related links component validation
                    var count = $(".number_of_tags").find("ul:nth-child(2)").find("li").length;
                    if (count > 5 || count < 1) {
                        alert(CQ.I18n.getMessage("relatedLinksTagErrorMsg"));
                        $(".number_of_tags").find("ul:nth-child(2)").each(function() {
                            var ul = $(this);
                            var $articleCount = ul.find('li').length;
                            while ($articleCount > 5) {
                                ul.find('li:last-child').remove();
                                $articleCount = ul.find('li').length;
                            }
                        });
                    } else {
                        handleResponse(form, submitForm(form));
                    }
                } else if (!(form.serialize().indexOf("aigVanityPath") > -1)) { //vanity uniqueness validation
                    handleResponse(form, submitForm(form));
                } else {
                    for (var n = 0; n < tabSerialize.length; n++) {
                        if (tabSerialize[n].indexOf("aigVanityPath") > -1) {

                            vanitytotalString = vanitytotalString + "," + tabSerialize[n].replace(".%2FaigVanityPath=", "");
                        }
                    }
                    var path = window.location.pathname;
                    var path1 = path.replace("/editor.html/", "/");
                    var path2 = path1.replace(".html", "/jcr:content");

                    $.ajax({
                        type: 'GET',
                        url: '/apps/duplicateVanityCheck',
                        data: 'pagePath=' + path2 + '&value=' + vanitytotalString.substring(1),
                        success: function(dataCheck) {

                            if (dataCheck.message != null && dataCheck.message != "") {
                                alert(dataCheck.message); //display the data returned by the servlet
                            } else {
                                handleResponse(form, submitForm(form));
                            }
                        }
                    });
                }
            }
        }
    });


    /**
     * Provides API related to foundation-form. This is returned class from jQuery adaptTo.
     *
     * @namespace FoundationForm
     * @see jQuery.fn.adaptTo
     */
    $(window).adaptTo("foundation-registry").register("foundation.adapters", {
        type: "foundation-form",
        selector: "form.foundation-form",
        adapter: function(el) {
            var form = $(el);

            return /** @lends FoundationForm */ {
                /**
                 * Resets the form. This method is intended to also reset <code>foundation-field</code>
                 * in addition to standard form controls.
                 *
                 * @instance
                 *
                 * @param {Boolean} skipNative Skips the native form reset method (HTMLFormElement#reset)
                 */
                reset: function(skipNative) {
                    if (!skipNative) {
                        el.reset();
                    }

                    form.find(".foundation-field-editable").each(function() {
                        var editable = $(this);
                        resetField(editable.find(".foundation-field-readonly"));
                        resetField(editable.find(".foundation-field-edit"));
                    });
                }
            };
        }
    });


    // @deprecated .foundation-form.mode-default and .foundation-form.mode-edit; please use foundation-layout-form instead.
    // The following code is for backward compatibility only

    $(document).on("foundation-mode-change", function(e, mode, group) {
        if (mode !== "default" && mode !== "edit") return;

        var executed = false;

        // only select form that is not .foundation-layout-form, as this code is for backward compatibility only
        $(".foundation-form:not(.foundation-layout-form)").each(function() {
            var el = $(this);

            if (group === el.data("foundationModeGroup")) {
                var edit = mode === "edit";
                el.toggleClass("mode-edit", edit).toggleClass("mode-default", !edit);

                executed = true;

                if (window.console) {
                }
            }
        });

        if (executed) {
            // FIXME Knowing that we have to trigger resize event here is not good
            // reflow the layout
            $(window).resize();
        }
    });
})(document, window, Granite.$, History);