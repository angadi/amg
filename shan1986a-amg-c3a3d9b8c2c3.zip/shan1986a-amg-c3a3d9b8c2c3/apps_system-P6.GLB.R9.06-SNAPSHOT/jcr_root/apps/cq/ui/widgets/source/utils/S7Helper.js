$(document).ready(function() {
     var href = window.location.href;
     var cfIndex = href.indexOf("/cf#");
          if(cfIndex > 0) { 
               var  pathStr = href.split("/cf#");
               var  currentPath = pathStr[1]; 
                     $.ajax({
    	                       url: "/bin/services/SceneSevenPathMappingService",
    	                       type: "GET",
                               data: {"currentPath":currentPath},
    	                       success: function (repsonse) {
                                         CQ.S7.sceneSevenHelperPath = repsonse;
    	                                  },
    	                       error: function (xhr, desc, err) {
    		                            CQ.Ext.Msg.alert(CQ.I18n.getMessage('ERROR'), CQ.I18n.getMessage('An error occurred while submitting your request. Please report this error to the DMFC team. {0}',[err]));
    	                                         }
                              });
                     }
})