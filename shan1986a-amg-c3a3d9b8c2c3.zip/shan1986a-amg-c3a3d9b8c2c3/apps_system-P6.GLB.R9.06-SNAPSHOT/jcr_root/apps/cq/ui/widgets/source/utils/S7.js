/*
 * Copyright 1997-2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */

/**
 * A helper class providing a set of S7-related utilities.
 */
CQ.utils.S7 = {

    THUMBS_TEMPLATE:
        '<tpl for=".">' +
            '<tpl if="CQ.S7.hasQuery(values.thumb)">' +
                '<div class="thumb-wrap">' +
                    '<div class="thumb"' +
                        ' style="background-image:url(\'{[values.thumb]}&wid=152&nanos={[values.nanos]}\');"' +
                        ' ondblclick="CQ.wcm.ContentFinderTab.resultDblClick(event, \'{id}\',\'{pathEncoded}\',{isFolder},\'{ddGroups}\');"' +
                        ' qtip="<nobr>{[CQ.shared.Util.htmlEncode(CQ.shared.XSS.getXSSTablePropertyValue(values, \"type\"))]}</nobr>{[values.type ? "<br/>" : ""]}<nobr>{[CQ.shared.XSS.getXSSValue(CQ.shared.Util.htmlEncode(values.name))]}</nobr>"' +
                    '></div>' +
                    '<span>{shortTitle}</span>' +
                '</div>' +
            '</tpl>' +
            '<tpl if="CQ.S7.hasQuery(values.thumb)==false">' +
                '<div class="thumb-wrap">' +
                  '<div class="thumb"' +
                     ' style="background-image:url(\'{[values.thumb]}?wid=152&nanos={[values.nanos]}\');"' +
                     ' ondblclick="CQ.wcm.ContentFinderTab.resultDblClick(event, \'{id}\',\'{pathEncoded}\',{isFolder},\'{ddGroups}\');"' +
                     ' qtip="<nobr>{[CQ.shared.Util.htmlEncode(CQ.shared.XSS.getXSSTablePropertyValue(values, \"type\"))]}</nobr>{[values.type ? "<br/>" : ""]}<nobr>{[CQ.shared.XSS.getXSSValue(CQ.shared.Util.htmlEncode(values.name))]}</nobr>"' +
                  '></div>' +
                  '<span>{shortTitle}</span>' +
                '</div>' +
            '</tpl>' +
        '</tpl>' +
        '<div class="x-clear"></div>',


    DETAILS_TEMPLATE:
        '<tpl for=".">' +
            '<tpl if="CQ.S7.hasQuery(values.thumb)">' +
                '<div class="cq-cft-search-item" ondblclick="CQ.wcm.ContentFinderTab.resultDblClick(event, \'{id}\', \'{pathEncoded}\', {isFolder}, \'{ddGroups}\');">' +
                    '<div title="{pathEncodedTitle}" class="cq-cft-search-thumb"' +
                        // encode path not in externalize - otherwise "#" in asset name or path is not encoded
                        ' style="background-image:url(\'{[values.thumb]}&wid=64\');"></div>' +
                    '<div class="cq-cft-search-text-wrapper">' +
                        '<div class="cq-cft-search-title">{[CQ.shared.XSS.getXSSValue(values.name)]}</div>' +
                        '{[CQ.shared.XSS.getXSSTablePropertyValue(values, \"type\") ? "<div>" + CQ.shared.XSS.getXSSTablePropertyValue(values, \"type\") + " " + (CQ.shared.XSS.getXSSTablePropertyValue(values, \"cqContent\") == "true" ? "(CQ)" : "") + "</div>" : ""]}' +
                        '{[CQ.shared.XSS.getXSSTablePropertyValue(values, \"lastModified\") ? "<div>" + CQ.shared.XSS.getXSSTablePropertyValue(values, \"lastModified\") + "</div>" : ""]}' +
                    '</div>' +
                    '<div class="cq-cft-search-separator"></div>' +
                '</div>' +
            '</tpl>' +
            '<tpl if="CQ.S7.hasQuery(values.thumb)==false">' +
                '<div class="cq-cft-search-item" ondblclick="CQ.wcm.ContentFinderTab.resultDblClick(event, \'{id}\', \'{pathEncoded}\', {isFolder}, \'{ddGroups}\');">' +
                    '<div title="{pathEncodedTitle}" class="cq-cft-search-thumb"' +
                        // encode path not in externalize - otherwise "#" in asset name or path is not encoded
                        ' style="background-image:url(\'{[values.thumb]}?wid=64\');"></div>' +
                    '<div class="cq-cft-search-text-wrapper">' +
                        '<div class="cq-cft-search-title">{[CQ.shared.XSS.getXSSValue(values.name)]}</div>' +
                            '{[CQ.shared.XSS.getXSSTablePropertyValue(values, \"type\") ? "<div>" + CQ.S7.mapType(CQ.shared.XSS.getXSSTablePropertyValue(values, \"type\")) + " " + (CQ.shared.XSS.getXSSTablePropertyValue(values, \"cqContent\") == "true" ? "(CQ)" : "") + "</div>" : ""]}' +
                            '{[CQ.shared.XSS.getXSSTablePropertyValue(values, \"lastModified\") ? "<div>" + CQ.shared.XSS.getXSSTablePropertyValue(values, \"lastModified\") + "</div>" : ""]}' +
                         '</div>' +
                    '<div class="cq-cft-search-separator"></div>' +
                '</div>' +
            '</tpl>' +
        '</tpl>',

    dynamicMediaConfig: {},

    hasQuery:function (url) {
        return url.indexOf("?") == -1 ? false : true;
    },

    getCqRootPath:function (selectedS7Config) {
    	var cqRootPath = "";
    	var url = "";

        // only perform XHR if a S7 config is selected
        if (selectedS7Config
                && selectedS7Config != "") {
            url = CQ.HTTP.addParameter(selectedS7Config + "/jcr:content.config.json", "prop", "cqRootPath");

            var res = CQ.HTTP.get(url);

            var ret = $CQ.parseJSON(res.responseText);
            if (ret != null && ret.cqRootPath) {
            	cqRootPath = ret.cqRootPath.substring(0, ret.cqRootPath.length - 1); //chop slash
            }
        }
        return cqRootPath;
    },

    getRootPath:function (selectedS7Config) {
    	var rootPath = "";
        var url = "";

        // only perform XHR if a S7 config is selected
        if (selectedS7Config
                && selectedS7Config != "") {
        	url = CQ.HTTP.addParameter(selectedS7Config + "/jcr:content.config.json", "prop", "rootPath");
            var res = CQ.HTTP.get(url);
            var ret = $CQ.parseJSON(res.responseText);
            if (ret != null && ret.rootPath) {
                //here we want the real S7 root path and chop any sub paths
                rootPath = ret.rootPath.substring(0, ret.rootPath.indexOf("/"));
            }
        }

        return rootPath;
    },

    /**
     * @return the deafaut scene7 asset types used when requesting an asset search
     * not the "root path" in the S7
     */
    getDefaultSearchQualifiers:function () {
        return {"assetType":"Audio,Pdf,VideoCaption,Video,MasterVideo,MbrSet"};
    },

    /**
     * @return the set of qualifiers usee in scene7 search
     */
    getSearchQualifiers:function () {
        var ret = new Object();

        // Path
        var node = CQ.Ext.getCmp("cfTab-S7Browse-Tree").getSelectionModel().getSelectedNode();
        if (node != null) {
            var idx1 = node.getPath().lastIndexOf("/content/");
            if (idx1 == "0")
            {
				// This path should be site specific
                ret["path"] = CQ.S7.sceneSevenHelperPath + "/" + node.getPath().substring(9); ;
            }
            else
            {
            	ret["path"] = CQ.shared.HTTP.encodePath(node.getPath() + "/");
            }
        }

        // Search term
        var searchTerm = CQ.Ext.getCmp("cfTab-S7Browse-searchField").getRawValue();
        if (searchTerm != "") {
            ret["searchTerm"] = CQ.shared.HTTP.encodePath(searchTerm);
        }

        // Asset type
        var assetType = CQ.Ext.getCmp("cfTab-S7Browse-assetType").getValue();
        if (assetType != "" && assetType != "None") {
            if (assetType == "Video") {
                assetType = "Video,MasterVideo";
            }
            ret["assetType"] = assetType;
        } else {
			// Customized to remove unwanted values and add new ones
            ret["assetType"] = "Audio,Pdf,VideoCaption,Video,MasterVideo,MbrSet";
        }
        return ret;
    },

    /**
     * @return the config path of the selected S7 configuration
     */
    getSelectedConfigPath:function() {
    	var selectedS7ConfigPath = "";
    	var configSelector = CQ.Ext.getCmp("cfTab-S7Browse-S7ConfigSelector");

        if (typeof configSelector != "undefined") {
        	selectedS7ConfigPath = configSelector.value;
        }

        return selectedS7ConfigPath;
    },

    /**
     * @return the set of qualifiers usee in scene7 search
     */
    setSearchQualifiers:function (store) {
        var obj = CQ.S7.getSearchQualifiers();

        store.baseParams = null;
        store.lastOptions = null;

        // Path
        if (obj["path"] != null) {
            store.setBaseParam("path", obj["path"]);
        }

        // Search term
        if (obj["searchTerm"] != null) {
            store.setBaseParam("searchTerm", obj["searchTerm"]);
        }

        // Asset type
        if (obj["assetType"] != null) {
            store.setBaseParam("assetType", obj["assetType"]);
        }
    },

    /**
    *	Checks a set of callback options against the original store
    */
    checkStoreOptions: function(callbackOptions, store) {
		var sameValues = true;
		var checkParams = ["path", "searchTerm", "assetType"];

        for (var idx = 0 ; idx < checkParams.length ; idx++) {
            sameValues = sameValues && (
                						( !callbackOptions.params[checkParams[idx]] && !store.baseParams[checkParams[idx]] )
                						|| (callbackOptions.params[checkParams[idx]] === store.baseParams[checkParams[idx]])
        								);
        }

        return sameValues;
    },

    /**
     * Appends the searh query params to the search url
     * @param url
     * @param params
     */
    appendQuery:function (url, params) {
        if (params == null || params == "") {
            return url;
        }

        var amp = (params.charAt(0) == "&");
        var q = (params.charAt(0) == "?");

        if (url.indexOf("?") == -1) {
            if (amp) {
                return url + "?" + params.substring(1);
            } else if (q) {
                return url + params;
            } else {
                return url + "?" + params;
            }
        }
        else {
            if (CQ.S7.endsWith(url, "?")) {
                if (amp || q) {
                    return url + params.substring(1);
                } else {
                    return url + params;
                }
            }
            else {
                if (amp) {
                    return url + params;
                } else if (q) {
                    return url + "&" + params.substring(1);
                } else {
                    return url + "&" + params;
                }
            }
        }
    },

    endsWith:function (str, substr) {
        var idx = str.lastIndexOf(substr);
        return (idx >= 0 && idx == str.length - substr.length);
    },

    findLimits:function (str, searchStr1, searchStr2) {
        var idx1 = str.indexOf(searchStr1);
        var idx2 = -1;
        if (idx1 != -1) {
            idx2 = str.indexOf(searchStr2, idx1);
        }
        return [idx1, idx2];
    },

    mapType: function(type) {
    	 if (type == "MbrSet") {
             return CQ.I18n.getMessage("Adaptive Video Set");
         } else {
             return type;
         }
    },

    /**
     * Determines if Dynamic Media is enabled
     * @return {Boolean} with the status of Dynamic Media
     */
    isDynamicMediaEnabled: function() {
        CQ.S7.updateDynamicMediaConfiguration();
        var isDMEnabled = false;
        if (this.dynamicMediaConfig
                && typeof this.dynamicMediaConfig.dynamicMediaEnabled != "undefined") {
            isDMEnabled = this.dynamicMediaConfig.dynamicMediaEnabled;
        }

        return isDMEnabled;
    },

    /**
     * Updates the dynamic media configuration status
     */
    updateDynamicMediaConfiguration: function() {
        if (this.dynamicMediaConfig
                && typeof this.dynamicMediaConfig.dynamicMediaEnabled != "undefined") {
            return;
        }

        var dmConfigUrl = CQ.HTTP.externalize("/etc/dam/dynamicmediaconfig.1.json");

        var dmConfigResponse = CQ.HTTP.get(dmConfigUrl);

        if (CQ.HTTP.isOk(dmConfigResponse)) {
            var dmCfgJSON = $CQ.parseJSON(dmConfigResponse.responseText);
            if (dmCfgJSON
                    && dmCfgJSON.dynamicMediaEnabled) {
                // initialize Dynamic Media config
                this.dynamicMediaConfig = {
                        dynamicMediaEnabled: dmCfgJSON.dynamicMediaEnabled == true
                                || dmCfgJSON.dynamicMediaEnabled == "true",
                        oldComponentGroup: dmCfgJSON.oldGroup,
                        dynamicMediaGroupName: dmCfgJSON.dynamicMediaGroupName,
                        dynamicMediaS7Components: dmCfgJSON.dynamicMediaS7Components
                };
            }
        }
    },

    /**
     * Returns the option array for the S7 media browser asset type selector
     */
    // Customized to remove unwanted values and add new ones
    getSearchStoreOptionArray: function() {
        var optionArray = [["None", CQ.I18n.getMessage("None")],
                           ["Video", CQ.I18n.getMessage("Video")],
                           ["Audio", CQ.I18n.getMessage("Audio")],
                           ["Pdf", CQ.I18n.getMessage("Transcripts")],
                           ["VideoCaption", CQ.I18n.getMessage("Video Captions")],
                           ["MbrSet", CQ.I18n.getMessage("Adaptive Video Set")]];

        return optionArray;
    }
};

// shortcut
CQ.S7 = CQ.utils.S7;
