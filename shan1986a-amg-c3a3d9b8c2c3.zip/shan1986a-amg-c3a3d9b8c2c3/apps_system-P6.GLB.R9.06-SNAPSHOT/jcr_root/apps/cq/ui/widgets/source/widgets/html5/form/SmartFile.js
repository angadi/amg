/**
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2012 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 *
 */

/**
 * @class CQ.html5.form.SmartFile
 * @extends CQ.form.CompositeField
 * <p>The SmartFile is an intelligent file uploader.</p>
 * <p>If the browser supports HTML5, uploads are executed using the
 * HTML5 that provides a convenient way to handle uploads.
 * If the browser does not support such way of upload or if it is disabled by the corresponding
 * config option, a HTML fallback is used instead, which imposes some restrictions compared
 * with the HTML5 version.</p>
 * <p>Component linking may be used to validate form fields that depend on the content of
 * a SmartFile instance. Just add the name of the dependant SmartFile instance
 * as a linkedComponent property (type: String) to the corresponding field(s). The SmartFile
 * component will then call the {@link CQ.Ext.form.TextField#validate} method of the
 * linked form field to trigger the validation. There is also a SmartFile-specific VType
 * available: use "requiredOnLinkedData" for fields that are required only if the linked
 * SmartFile component has a file uploaded or referenced.</p>
 * @since 5.5, replaces {@link CQ.form.SmartFile}
 * @constructor
 * Creates a new SmartFile.
 * @param {Object} config The config object
 */

CQ.html5.form.SmartFile = CQ.Ext.extend(CQ.form.CompositeField, {

    /**
     * @cfg {String} iconResources
     * The path where the icons that represent supported file type are located (excluding
     * webapp context path; defaults to {@link CQ.themes.SmartFile#ICON_RESOURCES})
     */
    iconResources: null,

    /**
     * @cfg {Object} extensionToIcon
     * A table that assigns file types to icons. The icons must be located at the path
     * specified by the {@link #iconResources} config property. The file type is used as
     * property name, the icon's file name as property value. Defaults to
     * {@link CQ.themes.SmartFile#EXTENSION_TO_ICON}
     */
    extensionToIcon: null,

    /**
     * @cfg {String} defaultIcon
     * Icon to be used if no specific icon is defined (see {@link #extensionToIcon}). The
     * icons must be located at the path specified by the {@link #iconResources} config
     * property. Defaults to {@link CQ.themes.SmartFile#DEFAULT_ICON}.
     */
    defaultIcon: null,

    /**
     * @cfg {Boolean} useHTML5
     * True to use HTML5 upload (if supported by the browser)
     * Defaults to true.
     */
    useHTML5: true,  // #29068 - Use HTML5 Upload as default for DAM/WCM

    /**
     * @cfg {String} mimeTypes
     * MIME types allowed for uploading (each separated by a semicolon; wildcard * is
     * allowed; for example: "*.*" or "*.jpg;*.gif;*.png" (defaults to "*.*".)
     * Also support MIME type syntax; for example (image/jpg or image/*)
     */
    mimeTypes: null,

    /**
     * @cfg {String} mimeTypesDescription
     * A String that describes the allowed MIME types (defaults to "All files")
     */
    mimeTypesDescription: null,

    /**
     * @cfg {String[]} ddGroups
     * Groups involved in drag &amp; drop (no default specified)
     */
    ddGroups: null,

    /**
     * @cfg {String} ddAccept
     * MIME type definition of files that are allowed for referencing using drag &amp; drop
     * (defaults to "*")
     */
    ddAccept: null,

    /**
     * @cfg {Number} sizeLimit
     * Maximum size of a file to be uploaded in Megabytes; defaults to 0 (unlimited)
     */
    sizeLimit: 0,

    /**
     * Maximum number of files to be uploaded simultaneously; not yet supported, hence
     * flagged as private.
     * @private
     * @type Number
     */
    fileLimit: 0,

    /**
     * @cfg {String} invalidClass
     * CSS class to be used to mark the smart image component as invalid (defaults to
     * "cq-smartfile-invalid")
     */
    invalidClass: null,

    /**
     * Fixed height of the component
     * @private
     * @type Number
     */
    fixedHeight: null,

    /**
     * Current component width
     * @private
     * @type Number
     */
    compWidth: 0,

    /**
     * Current component height
     * @private
     * @type Number
     */
    compHeight: 0,

    /**
     * @cfg {String} fileNameParameter
     * Name of the form field used for posting the file name. Be aware that you will
     * have to specify a suitable value here, as there is no sensible default value
     * available. Suitable values are dependant on their serverside counterpart and must
     * be "./fileName" for CQ foundation's image and download components; use
     * "./image/fileName" for the textimage component.
     */
    fileNameParameter: null,

    /**
     * @cfg {String} fileReferenceParameter
     * Name of the form field used for posting the file reference. Be aware that you
     * will have to specify a suitable value here, as there is no sensible default
     * value available. Suitable values are dependant on their serverside counterpart
     * and must be "./fileReference" for CQ foundation's image and download components; use
     * "./image/fileReference" for the textimage component.
     */
    fileReferenceParameter: null,

    /**
     * @property {CQ.Ext.form.TextField} fileNameInputField
     * This property may be used to specify a textfield that is used to set a file name.
     * If this is set to null, no file name is transferred to the server
     */
    fileNameInputField: null,

    /**
     * The parameter to move the uploaded file.
     * @private
     * @type CQ.Ext.form.Hidden
     */
    moveParameter: null,

    /**
     * The parameter to delete the uploaded file.
     * @private
     * @type CQ.Ext.form.Hidden
     */
    deleteFileParameter: null,

    /**
     * The parameter to delete the temporary folder after moving.
     * @private
     * @type CQ.Ext.form.Hidden
     */
    deletePathParameter: null,

    /**
     * @cfg {String} lockIconCls
     * CSS class to use for displaying the lock icon (defaults to "cq-lock-placeholder")
     */
    lockIconCls: null,

    /**
     * @cfg {String} lockPanelCls
     * CSS class to be used for the lock panel (defaults to "cq-lock-panel")
     */
    lockPanelCls: null,

    /**
     * @cfg {String} lockHintCls
     * CSS class to be used for the lock panel (defaults to "cq-lock-hint")
     */
    lockHintCls: null,

    /**
     * @cfg {String} lockText
     * Text used in the upload panel if the component is locked through inheritance. (defaults
     * to "Click to cancel inheritance")
     */
    cancelInheritanceText: null,

    /**
     * @cfg {String} lockText
     * Text used in the upload panel if the component is locked through inheritance. (defaults
     * to "Click to revert inheritance")
     */
    revertInheritanceText: null,

    /**
     * @cfg {String} uploadText
     * Text used in the upload panel if both referencing and uploading are allowed (defaults
     * to "Drop an asset or click to upload")
     */
    uploadText: null,

    /**
     * @cfg {String} uploadTextUpload
     * Text used in the upload panel if uploading is allowed only (defaults to "Click to
     * upload")
     */
    uploadTextUpload: null,

    /**
     * @cfg {String} uploadTextReference
     * Text used in the upload panel if referencing is allowed only (defauls to "Drop an
     * asset")
     */
    uploadTextReference: null,

    /**
     * @cfg {String} uploadTextFallback
     * Text used in the upload panel if HTML5 is unavailable (defaults to "Upload file")
     */
    uploadTextFallback: null,

    /**
     * @cfg {String} uploadIconCls
     * CSS class to use for displaying the upload icon (defaults to "cq-file-placeholder")
     */
    uploadIconCls: null,

    /**
     * @cfg {String} uploadPanelCls
     * CSS class to be used for the upload panel (defaults to "cq-upload-border")
     */
    uploadPanelCls: null,

    /**
     * @cfg {String} uploadHintCls
     * CSS class to be used for the upload hint (defaults to "cq-upload-hint")
     */
    uploadHintCls: null,

    /**
     * @cfg {Boolean} removeUploadPanelClsOnProgress
     * True if the CSS class of the upload panel should be removed when the upload progress
     * is displayed (defaults to true)
     */
    removeUploadPanelClsOnProgress: false,

    /**
     * @cfg {Boolean} validateOnSubmitOnly
     * True if the component should be validated on submit only - and not on each state
     * change (defaults to false)
     */
    validateOnSubmitOnly: false,

    /**
     * @cfg {Boolean} allowUpload
     * Flag if uploading a file is allowed (defaults to true)
     */
    allowUpload: false,

    /**
     * @cfg {Boolean} allowFileReference
     * Flag if referencing a file is allowed (defaults to true)
     */
    allowFileReference: false,

    /**
     * @cfg {Boolean} allowFileNameEditing
     * True if the name of an uploaded file is editable (defaults to true)
     */
    allowFileNameEditing: false,

    /**
     * @cfg {Boolean} transferFileName
     * True if the filename has to be submitted as a separate form field (defaults to true)
     */
    transferFileName: false,

    /**
     * @cfg {String} noFileNameText
     * Text to display if no file name is given (defaults to "???")
     * @since 5.4
     */
    noFileNameText: "",

    /**
     * Flag if a new file has been uploaded to the repository (hence the existing file will
     * be replaced when the user finishes using the "OK" button)
     * @private
     * @type Boolean
     */
    isUploaded: false,

    /**
     * Element that represents upload hint
     * @private
     * @type CQ.Ext.Element
     */
    textEl: null,

    /**
     * Element that represents lock hint
     * @private
     * @type CQ.Ext.Element
     */
    lockTextEl: null,

    /**
     * Panel that holds the HTML5 upload component and later displays the upload progress bar
     * @type CQ.Ext.Panel
     * @private
     */
    uploadPanel: null,

    /**
     * The current info of the file if the component represents an uploaded file;
     * null if the component represents a referenced file or does not contain any data.
     * @type Object
     * @private
     */
    fileInfo: null,

    /**
     * Info of the uploaded instance in the repository; null if the instance in the
     * repository references a file or is empty
     * @type Object
     * @private
     */
    serverFileInstance: null,

    /**
     * The current info of the file if the component represents a referenced file;
     * null if the component represents an uploaded file or does not contain any data.
     * @type Object
     * @private
     */
    referencedFileInfo: null,

    /**
     * @cfg {String} renditionSuffix
     * Suffix for requesting referenced images in their web rendition state from DAM.
     * If the suffix does not include the extension it will be added programmatically.
     * (defaults to "/jcr:content/renditions/cq5dam.web.1280.1280")
     */
    renditionSuffix: null,

    /**
     * @cfg {String} fallbackRenditionSuffix
     * Suffix for requesting referenced images in their original state from DAM (defaults
     * to "/jcr:content/renditions/original") in case the renditionSuffix is not valid
     */
    fallbackRenditionSuffix: null,

    /**
     * @cfg {CQ.Ext.Panel} headPanel
     * A panel that is added above the SmartFile's working area (defaults to null)
     */
    headPanel: null,

    /**
     * @cfg {CQ.Ext.Panel} footPanel
     * A panel that is added below the SmartFile's working area (defaults to null)
     */
    footPanel: null,

    /**
     * ID of the SmartImage instance; unique for each page; required for Selenium testing
     * @private
     * @type Number
     */
    instanceId: 0,

    constructor: function(config) {
        this.instanceId = CQ.html5.form.SmartFile.ID_COUNTER++;

        // #29068 - Use HTML5 Upload as default for DAM/WCM
        this.useHTML5 = config.useHTML5 != undefined ? config.useHTML5 : true;
        if (!CQ.html5.Util.isUploadSupported()) {
            this.useHTML5 = false;
        }

        config = config || {};
        var defaults = {
            "hideBorders": true,
            "border": false,
            "anchor": CQ.themes.Dialog.ANCHOR,
            "mimeTypes": "*.*",
            "mimeTypesDescription": CQ.I18n.getMessage("All files"),
            "ddAccept": "*",
            "sizeLimit": 0,
            "fileLimit": 100,
            "stateful": false,
            "allowBlank": true,
            "validateOnSubmitOnly": false,
            "invalidClass": "cq-smartfile-invalid",
            "allowUpload": true,
            "allowFileReference": true,
            "allowFileNameEditing": true,
            "transferFileName": true,
            "noFileNameText": "???",
            "uploadPanelCls": "cq-upload-border",
            "uploadHintCls": "cq-upload-hint",
            "removeUploadPanelClsOnProgress": true,
            "lockIconCls": "cq-lock-placeholder",
            "lockHintCls": "cq-lock-hint",
            "lockPanelCls": "cq-lock-panel",
            "uploadIconCls": "cq-file-placeholder",
            "uploadTextUpload": CQ.I18n.getMessage("Click to upload"),
            "uploadTextReference": CQ.I18n.getMessage("Drop an asset"),
            "uploadTextFallback": CQ.I18n.getMessage("Upload file"),
            "uploadText": CQ.I18n.getMessage("Drop an asset or click to upload"),
            "cancelInheritanceText": CQ.I18n.getMessage("Click to cancel inheritance"),
            "revertInheritanceText": CQ.I18n.getMessage("Click here to revert inheritance"),
            "iconResources": CQ.themes.SmartFile.ICON_RESOURCES,
            "extensionToIcon": CQ.themes.SmartFile.EXTENSION_TO_ICON,
            "defaultIcon": CQ.themes.SmartFile.DEFAULT_ICON,
            "renditionSuffix": CQ.html5.form.SmartFile.DAM_RENDITIONS_PATH + CQ.html5.form.SmartFile.DAM_WEB_RENDITION_NAME,
            "fallbackRenditionSuffix": CQ.html5.form.SmartFile.DAM_RENDITION_SUFFIX,
            "height": 120,
            "listeners": {
                resize: this.onComponentResize,
                fileselected: this.onFileSelected
            },
            useHTML5: this.useHTML5
        };

        // add compatibility to pre-release versions of CQ5 which used the
        // allowFileReferenceOnly/allowUploadOnly properties
        if (config.allowFileReferenceOnly !== undefined) {
            config.allowFileReference = !config.allowFileReferenceOnly;
            delete config.allowFileReferenceOnly;
        }
        if (this.allowUploadOnly !== undefined) {
            config.allowUpload = !config.allowUploadOnly;
            delete config.allowUploadOnly;
        }

        // ensure that at least file referencing is allowed
        if (!config.allowFileReference && !config.allowUpload) {
            config.allowFileReference = true;
        }

        // override these values directly, as they might be preset in the config by the
        // Dialog component
        config.autoScroll = false;
        config.bodyStyle = "padding: 0px; overflow: hidden;";
        config.layout = "border";

        CQ.Util.applyDefaults(config, defaults);
        if (config.height && (config.height != "auto")) {
            this.fixedHeight = config.height;
        } else {
            this.fixedHeight = null;
        }

        CQ.html5.form.SmartFile.superclass.constructor.call(this, config);
    },

    // overriding CQ.form.CompositeField#initComponent
    initComponent: function() {
        CQ.html5.form.SmartFile.superclass.initComponent.call(this);
        var parentScope = this;

        // Container panel for original SmartFile panels
        this.containerPanel = new CQ.Ext.Panel({
            "region": "center",
            "ctCls": CQ.DOM.encodeClass("smartfile-" + this.name),
            "activeItem": 0,
            "autoScroll": false,
            "bodyStyle": "padding: 0px; overflow: hidden;",
            "layout": "card"
        });
        this.add(this.containerPanel);

        this.lockPanel = new CQ.Ext.Panel( {
            "itemId": "lock",
            "cls": this.lockPanelCls,
            "layout": "fit",
            "border": false,
            "style": "padding: 0;",
            "bodyStyle": "position: relative; top: 0; left: 0;",
            "listeners": {
                "resize": function(panel, width, height) {
                    if (typeof width == "object") {
                        height = width.height;
                        width = width.width;
                    }
                    this._width = width;
                    this._height = height;
                    if (this.rendered) {
                        parentScope.setTextElSize(parentScope.lockTextEl, width, height);
                    }
                }
            },
            "afterRender": function() {
                CQ.Ext.Panel.prototype.afterRender.call(this);
                this.el.setVisibilityMode(CQ.Ext.Element.DISPLAY);
                this.body.setVisibilityMode(CQ.Ext.Element.DISPLAY);
                if (parentScope.fixedHeight) {
                    var height = parentScope.fixedHeight;
                    this.el.setHeight(height);
                    this.body.setHeight(height - this.el.getBorderWidth("tb"));
                }
            }
        } );
        this.containerPanel.add(this.lockPanel);

        // Basic panels
        this.uploadPanel = new CQ.Ext.Panel( {
            "itemId": "upload",
            "cls": this.uploadPanelCls,
            "layout": "fit",
            "border": false,
            "style": "padding: 0;",
            "bodyStyle": "position: relative; top: 0; left: 0;",
            "listeners": {
                "resize": function(panel, width, height) {
                    if (typeof width == "object") {
                        height = width.height;
                        width = width.width;
                    }
                    this._width = width;
                    this._height = height;
                    if (this.rendered) {
                        parentScope.setTextElSize(parentScope.textEl, width, height);
                        parentScope.setProgressBarSize(width, height);
                    }
                }
            },
            "afterRender": function() {
                CQ.Ext.Panel.prototype.afterRender.call(this);
                this.el.setVisibilityMode(CQ.Ext.Element.DISPLAY);
                this.body.setVisibilityMode(CQ.Ext.Element.DISPLAY);
                if (parentScope.fixedHeight) {
                    var height = parentScope.fixedHeight;
                    this.el.setHeight(height);
                    this.body.setHeight(height - this.el.getBorderWidth("tb"));
                }
            }
        } );
        this.containerPanel.add(this.uploadPanel);

        // file name editor
        this.createFileNameEditingCapability();

        this.processingPanel = this.createProcessingPanel();
        this.containerPanel.add(this.processingPanel);

        // hidden interface fields
        this.createHiddenInterfaceFields();

        // insert customized panels
        if (this.headPanel) {
            this.headPanel.region = "north";
            this.add(this.headPanel);
        }
        if (this.footPanel) {
            this.footPanel.region = "south";
            this.add(this.footPanel);
        }

        if (!this.useHTML5) {
            var fbfCfg = {
                "name": this.name,
                "fieldLabel":this.uploadTextFallback,
                "fileNameParameter": this.fileNameParameter,
                "allowFileNameEditing": this.allowFileNameEditing,
                html5Upload: false,
                multiple: false,
                mimeTypes: this.mimeTypes,
                mimeTypesDescription: this.mimeTypesDescription,
                removable: false,
                targetEl: this
            };
            if (this.fullTab) {
                fbfCfg.fieldLabel = this.uploadTextFallback;
            }
            this.fallbackFileField = new CQ.html5.form.FileUploadField(fbfCfg);
            var fbpCfg = {
                "itemId": "fallback",
                "layout":"form",
                "defaults": {
                    "anchor": CQ.themes.Dialog.ANCHOR
                },
                "hideMode":"offsets", // needed to calculate button width
                "border": false,
                "items": this.fallbackFileField
            };
            if (this.fullTab) {
                fbpCfg.bodyStyle = CQ.themes.Dialog.TAB_BODY_STYLE;
            } else {
                fbpCfg.defaults.hideLabel = true;
            }
            this.fallbackPanel = new CQ.Ext.Panel(fbpCfg);
            this.containerPanel.add(this.fallbackPanel);
        }

    },

    /**
     * <p>Get the top level component for the SmartFile.</p>
     * <p>This is usually the {@link CQ.Dialog} it is used from. If used from outside a
     * dialog, the corresponding form panel is returned.</p>
     * @return {CQ.Dialog/CQ.Ext.form.FormPanel} the top level component for the SmartFile;
     *         null if the SmartFile is neither used in a dialog, nor in a form panel
     * @private
     */
    getToplevel: function() {
        var dialog = this.findParentByType("dialog");
        if (!dialog) {
            dialog = this.findParentByType(CQ.Ext.form.FormPanel);
        }
        return dialog;
    },

    // overriding CQ.Ext.Panel#onRender
    onRender: function(ct, pos) {
        CQ.html5.form.SmartFile.superclass.onRender.call(this, ct, pos);
        this.el.setVisibilityMode(CQ.Ext.Element.DISPLAY);
        this.body.setVisibilityMode(CQ.Ext.Element.DISPLAY);
        var dialog = this.findParentByType("dialog");
        if (dialog) {
            dialog.on("beforesubmit", function() {
                this.syncFormElements();
                return this.onBeforeSubmit();
            }, this);
        } else {
            var form = this.findParentByType(CQ.Ext.form.FormPanel);
            if (form) {
                var frm = form.getForm();
                frm.on("beforeaction", function() {
                    this.syncFormElements();
                    return this.onBeforeSubmit();
                }, this);
            }
        }
    },

    // overriding CQ.form.CompositeField#afterRender
    afterRender: function() {
        CQ.html5.form.SmartFile.superclass.afterRender.call(this);
        this.initializeDragAndDrop();
    },

    /**
     * Handler that reacts on resizing events. The new width and height are saved to
     * properties {@link #compWidth} and {@link #compHeight}.
     * @param {Number/Object} width Width or object with both width and height (properties:
     *        width, height)
     * @param {Number} height (optional) Height (only used when width is of type Number)
     * @private
     */
    onComponentResize: function(width, height) {
        if (typeof width == "object") {
            height = width.height;
            width = width.width;
        }
        this.compWidth = width;
        this.compHeight = height;
    },

    switchPropertyInheritance: function() {
        // todo: not yet available for SmartFile
    },

    // Validation --------------------------------------------------------------------------

    // overriding CQ.form.CompositeField#markInvalid
    markInvalid: function(msg) {
        if (!this.rendered || this.preventMark) { // not rendered
            return;
        }
        msg = msg || this.invalidText;
        this.uploadPanel.body.addClass(this.invalidClass);
        this.processingPanel.markInvalid(this.invalidClass);
        this.uploadPanel.body.dom.qtip = msg;
        this.uploadPanel.body.dom.qclass = 'x-form-invalid-tip';
        if (CQ.Ext.QuickTips) { // fix for floating editors interacting with DND
            CQ.Ext.QuickTips.enable();
        }
        this.fireEvent('invalid', this, msg);
    },

    // overriding CQ.form.CompositeField#clearInvalid
    clearInvalid: function(){
        if (!this.rendered || this.preventMark) { // not rendered
            return;
        }
        this.uploadPanel.body.removeClass(this.invalidClass);
        this.processingPanel.clearInvalid(this.invalidClass);
        this.fireEvent('valid', this);
    },

    /**
     * Validates the component after a state change and notifies all linking components
     * about this status change.
     * @private
     */
    validateOnStateChange: function() {
        if (!this.validateOnSubmitOnly) {
            this.validate();
        }
        this.validateLinkingFieldsOnStateChange();
    },

    /**
     * Validates all fields of the dialog that are linking to this instance of SmartFile on
     * a state change.
     * @private
     */
    validateLinkingFieldsOnStateChange: function() {
        var dialog = this.getToplevel();
        if (dialog) {
            var dialogComponents = CQ.Util.findFormFields(dialog);
            if (dialogComponents) {
                for (var componentName in dialogComponents) {
                    if (dialogComponents.hasOwnProperty(componentName)) {
                        var components = dialogComponents[componentName];
                        var componentCnt = components.length;
                        for (var compIndex = 0; compIndex < componentCnt; compIndex++) {
                            var component = components[compIndex];
                            if (component.linkedComponent == this.name) {
                                component.validate();
                            }
                        }
                    }
                }
            }
        }
    },

    /**
     * Checks if the widget has data, i.e. if a file is uploaded or has been referenced.
     * @return {Boolean} True if the widget contains data
     */
    hasData: function() {
        return (this.fileInfo != null) || (this.referencedFileInfo != null);
    },

    /**
     * Checks if a file is currently uploaded.
     * @return {Boolean} True if a file is currently uploaded, else false
     */
    hasUploadedData: function() {
        return (this.fileInfo != null);
    },

    /**
     * Checks if a file is currently referenced.
     * @return {Boolean} True if a file is currently referenced, else false
     */
    hasReferencedData: function() {
        return (this.referencedFileInfo != null);
    },


    // Form interface ----------------------------------------------------------------------

    /**
     * <p>Creates a capability for editing the name of a file in the form of an additional
     * text field (created as private property fileNameField) that is added to
     * containerPanel.</p>
     * <p>This behaviour may be overridden by implementing classes to provide more suitable
     * means for editing the file name. It should still add at least a hidden field as
     * property fileNameField that is used for transferring the actual file name.</p>
     * @private
     */
    createFileNameEditingCapability: function() {
        if (!this.allowFileNameEditing) {
            this.fileNameField = new CQ.Ext.form.Hidden( {
                "disabled": !this.transferFileName
            } );
        } else {
            this.fileNameField = new CQ.Ext.form.TextField({
                "autoHeight": false
            });
            this.transferFileName = true;
        }
        this.containerPanel.add(this.fileNameField);
    },

    /**
     * <p>Creates all hidden fields that are required for submitting the component to the
     * server.</p>
     * <p>This method may be overridden by implementing classes to specify additional
     * form fields that have to be submitted. Each of these additional form fields have to
     * be added to contentPanel explictly.</p>
     * @private
     */
    createHiddenInterfaceFields: function() {
        // Hidden fields
        this.fileReferenceField = new CQ.Ext.form.Hidden( {
            "disabled": true
        } );
        this.containerPanel.add(this.fileReferenceField);
        this.moveParameter = new CQ.Ext.form.Hidden( {
            "disabled": true
        } );
        this.containerPanel.add(this.moveParameter);
        this.deleteFileParameter = new CQ.Ext.form.Hidden( {
            "disabled": true,
            "value": "true"
        } );
        this.containerPanel.add(this.deleteFileParameter);
        this.deletePathParameter = new CQ.Ext.form.Hidden( {
            "disabled": true,
            "value": "true"
        } );
        this.containerPanel.add(this.deletePathParameter);
        this.lastModifiedParameter = new CQ.Ext.form.Hidden( {
            "disabled": true,
            "value": ""
        });
        this.containerPanel.add(this.lastModifiedParameter);
        this.lastModifiedByParameter = new CQ.Ext.form.Hidden( {
            "disabled": true,
            "value": ""
        });
        this.containerPanel.add(this.lastModifiedByParameter);
    },

    /**
     * <p>This method is called directly before the form is being submitted. The form
     * elements are already synched with the model.</p>
     * <p>Implementing classes may override this.</p>
     * @return {Boolean} True to actually submit the form; false to cancel submitting
     * @private
     */
    onBeforeSubmit: function() {
        return true;
    },


    // Model -------------------------------------------------------------------------------

    /**
     * <p>Get the "raw value" of the component.</p>
     * <p>The value is a composite of all available information about the current state of
     * the component, in the form of a string representation. This value is used for
     * supporting Ext's internal validation framework.</p>
     * <p>Note that {@link #getValue} will always return the value explicitly set by
     * {@link #setValue}, whereas getRawValue always returns a string representation of the
     * internal state of the component.</p>
     * @return {String} The raw value of the component
     */
    getRawValue: function() {
        var stringRep = "";
        if (this.fileInfo) {
            stringRep += "[instance:\"" + this.fileInfo.dataPath + "\" \""
                    + this.fileInfo.mimeType + "\" " + this.fileInfo.size + "]";
        }
        if (this.referencedFileInfo) {
            stringRep += "[reference:\"" + this.referencedFileInfo.dataPath + "\" \""
                    + this.referencedFileInfo.mimeType + "\" "
                    + this.referencedFileInfo.size + "]";
        }
        if (this.fileNameInputField) {
            stringRep += "[fileName:\"" + this.fileNameInputField.getValue() + "\"]";
        }
        return stringRep;
    },

    /**
     * Creates the URL of a referenced image.
     * @param {Object} refFileInfo The file info for the referenced image; property
     *        dataPath and renditions is required
     * @return {String} The URL to be used for requesting the original referenced image
     * @private
     */
    createRefUrl: function(refFileInfo) {
        var ext = "";
        this.renditionSuffix = CQ.html5.form.SmartFile.DAM_RENDITIONS_PATH + CQ.html5.form.SmartFile.DAM_WEB_RENDITION_NAME ;
        for (var r in refFileInfo.renditions) {
            var rPath = CQ.html5.form.SmartFile.DAM_RENDITIONS_PATH + r;
            if (rPath == this.renditionSuffix) {
                // suffix defined incl. extension resp. no extension (e.g. "original")
                break;
            }
            if (rPath.indexOf(this.renditionSuffix) == 0) {
                ext = r.substring(r.lastIndexOf("."));
                break;
            }
        }
        var url = refFileInfo.dataPath + this.renditionSuffix + ext;
        return CQ.HTTP.externalize(CQ.shared.HTTP.encodePath(url), true);
    },

    /**
     * Creates the URL the fallback variant of a referenced image is requested with.
     * @param {Object} refFileInfo The file info for the referenced image; property
     *        dataPath is required
     * @return {String} The URL to be used for requesting the original referenced image
     * @private
     */
    createFallbackRefUrl: function(refFileInfo) {
        var url = refFileInfo.dataPath + this.fallbackRenditionSuffix;
        return CQ.HTTP.externalize(CQ.shared.HTTP.encodePath(url), true);
    },

    /**
     * Gets the currently most suitable file info object (considering that references
     * "overlay" uploaded files).
     * @return {Object} The most suitable file info object; properties: fileName, dataPath,
     *         url, mimeType, size (not all properties may be available at all times)
     * @private
     */
    getSuitableFileInfo: function() {
        if (this.referencedFileInfo != null) {
            return this.referencedFileInfo;
        }
        return this.fileInfo;
    },

    /**
     * Processes a newly created instance, with no content yet.
     * @param {String} path Base path for resolving relative file paths
     * @private
     */
    processPath: function(path, ignoreData) {
        if (ignoreData) {
            // ignoreData true: processRecord will not be called
            this.dataPath = path;
            this.isUploaded = false;
            this.fileInfo = null;
            this.referencedFileInfo = null;
            this.validateOnStateChange();
            this.syncFormElements();
            this.updateView();

            // add marker field for undoing binary changes
            if (CQ.undo.UndoManager.isEnabled()) {
                CQ.undo.util.UndoUtils.addBlobMarkerField(this.getToplevel(), {
                    "type": "create",
                    "path": path,
                    "field": this.getName()
                });
            }
        }
    },

    // overriding CQ.form.CompositeField#processRecord
    processRecord: function(record, path) {
        if (this.fireEvent('beforeloadcontent', this, record, path) !== false) {
            if ("allowUpload" in record.data) {
                this.allowUpload = record.data.allowUpload;
            }
            this.dataPath = path;
            this.isUploaded = false;
            this.fileInfo = null;
            this.referencedFileInfo = null;
            var fileName;
            if (this.fileNameParameter) {
                fileName = record.get(this.fileNameParameter);
            }
            if (this.fileReferenceParameter) {
                var fileRef = record.get(this.fileReferenceParameter);
                if (fileRef) {
                    this.referencedFileInfo = this.resolveReference(fileRef, path);
                    if (this.referencedFileInfo != null) {
                        if (fileName) {
                            this.referencedFileInfo.fileName = fileName;
                        }
                        this.referencedFileInfo.url = this.createRefUrl(
                            this.referencedFileInfo);
                        this.referencedFileInfo.fallbackUrl = this.createFallbackRefUrl(
                            this.referencedFileInfo);
                    }
                }
            }
            var value = record.get(this.name);
            if (value) {
                if (value["jcr:content"]) {
                    value = CQ.Sling.processBinaryData(value["jcr:content"]);
                } else {
                    value = CQ.Sling.processBinaryData(value);
                }
                if (value) {
                    var dataPath = CQ.Sling.getContentPath(this.name, path);
                    this.fileInfo = {
                        "fileName": fileName,
                        "dataPath": dataPath,
                        "mimeType": value.type,
                        "size": value.size,
                        "url": CQ.HTTP.externalize(dataPath, true)
                    };
                    this.serverFileInstance = this.fileInfo;
                }
            }
            this.postProcessRecord(record, path);
            this.validateOnStateChange();
            this.syncFormElements();
            this.updateView();

            // add marker field for undoing binary changes
            if (CQ.undo.UndoManager.isEnabled()) {
                var topLevel = this.getToplevel();
                CQ.undo.util.UndoUtils.addBlobMarkerField(this.getToplevel(), {
                    "type": "update",
                    "path": path,
                    "field": this.getName()
                });
                // workaround for bug #38022
                // TODO to be removed
                var form = (topLevel.getXType() == "dialog" ? topLevel.form :
                        (topLevel.getXType() == "form" ? topLevel.getForm() : null));
                if (form) {
                    if (this.fileNameField && !form.items.contains(this.fileNameField)) {
                        form.add(this.fileNameField)
                    }
                    // TODO more required?
                }
            }

            this.fireEvent('loadcontent', this, record, path);
        }
    },

    /**
     * <p>This method may be used to do some implementation specific post-processing.</p>
     * <p>This mechanism should be used rather than overriding {@link #processRecord}.</p>
     * @param {CQ.data.SlingRecord} record The record to be processed
     * @param {String} path Base path for resolving relative file paths
     * @private
     */
    postProcessRecord: function(record, path) {
        // may be overridden by implementing method
    },

    /**
     * Resolves an external file reference.
     * @param {String} fileRef The path to the external file to be resolved
     * @param {String} basePath The base path to resolve relative references; optional if
     *        fileRef contains an absolute path
     * @return {Object} A suitable file info object for the specified reference (properties:
     *         fileName, dataPath, url, mimeType, size - not all properties are available
     *         at any time); null, if the reference could not be resolved
     * @private
     */
    resolveReference: function(fileRef, basePath) {
        var refFileInfo = null;
        var originalFileRef = fileRef;
        try {
            if (fileRef.indexOf("/") == 0) {
                fileRef = fileRef + "/jcr:content.infinity";
                var json = CQ.HTTP.eval(CQ.shared.HTTP.encodePath(fileRef) + CQ.HTTP.EXTENSION_JSON);
                var refValue = CQ.Util.formatData(json);
                if (refValue) {
                    refFileInfo = CQ.Sling.processBinaryData(refValue);
                    if (refFileInfo.renditions && refFileInfo.renditions.original &&
                            refFileInfo.renditions.original["jcr:content"]) {
                        refFileInfo.size = refFileInfo.renditions.original["jcr:content"][":jcr:data"];
                        refFileInfo.mimeType = refFileInfo.renditions.original["jcr:content"]["jcr:mimeType"];
                    }
                    if (!refFileInfo.mimeType && refFileInfo.metadata) {
                        refFileInfo.mimeType = refFileInfo.metadata["dc:format"];
                    }
                    if (basePath) {
                        refFileInfo.dataPath = CQ.Sling.getContentPath(originalFileRef,
                                basePath);
                        refFileInfo.url = CQ.HTTP.externalize(refFileInfo.dataPath);
                    } else {
                        refFileInfo.dataPath = originalFileRef;
                        refFileInfo.url = originalFileRef;
                    }
                }
            } else {
                refFileInfo = {
                    "dataPath": fileRef,
                    "url": fileRef
                };
            }
        }
        catch (e) {
            CQ.Log.error("SmartFile#resolveReference: failed to resolve reference: " + e.message);
        }
        return refFileInfo;
    },

    /**
     * <p>Synchronizes form elements with the current UI state.</p>
     * <p>All form fields are adjusted accordingly.</p>
     * @private
     */
    syncFormElements: function() {
        var fileName = this.name;
        if (this.uploadName) {
            fileName = this.uploadName;
            if (fileName.length < 2 || fileName.substring(0, 2) != "./") {
                fileName = "./" + fileName;
            }
        }

        // adapt field names
        if (this.fileNameField) {
            if (!this.fileNameParameter) {
                this.fileNameParameter = fileName + CQ.html5.form.SmartFile.PARAM_FILENAME_SUFFIX;
            }
            if (this.useHTML5 || this.containerPanel.layout.activeItem.itemId != "fallback") {
                this.fileNameField.getEl().dom.name = this.fileNameParameter;
                if (this.fallbackFileField) {
                    this.fallbackFileField.getEl().dom.name = "";
                }
            } else {
                // removeAttribute seems not to work in IE - therefore set name=""
                this.fileNameField.getEl().dom.name = "";
                this.fallbackFileField.getEl().dom.name = this.fileNameParameter;
            }
        }
        if (this.fileReferenceField) {
            if (!this.fileReferenceParameter) {
                this.fileReferenceParameter = fileName + CQ.html5.form.SmartFile.PARAM_REFERENCE_SUFFIX;
            }
            this.fileReferenceField.getEl().dom.name = this.fileReferenceParameter;
        }
        if (this.moveParameter) {
            this.moveParameter.getEl().dom.name = fileName + CQ.Sling.MOVE_SUFFIX;
        }
        if (this.deleteFileParameter) {
            this.deleteFileParameter.getEl().dom.name = fileName + CQ.Sling.DELETE_SUFFIX;
        }
        // adjust field values
        if (this.fileReferenceField) {
            var fileRefPath = (this.referencedFileInfo ? this.referencedFileInfo.dataPath
                    : "");
            this.fileReferenceField.setValue(fileRefPath);
            this.fileReferenceField.enable();
        }
        if (this.moveParameter) {
            if (this.fileInfo && this.isUploaded) {
                this.moveParameter.setValue(this.fileInfo.dataPath);
                this.moveParameter.enable();
            } else {
                this.moveParameter.disable();
            }
        }
        if (this.useHTML5 && this.deleteFileParameter) {
            if (this.serverFileInstance && !this.fileInfo) {
                this.deleteFileParameter.enable();
            } else {
                this.deleteFileParameter.disable();
            }
        }
        // handle jcr:lastModified(By) for composites (when the image is a child node of the
        // actual component)
        var enableLastModifiedFields = false;
        var lastModifiedPrefix;
        var sepPos = fileName.lastIndexOf("/");
        if (sepPos > 0) {
            var path = fileName.substring(0, sepPos);
            if (path != ".") {
                enableLastModifiedFields = true;
                lastModifiedPrefix = path;
            }
        }
        if (enableLastModifiedFields) {
            this.lastModifiedParameter.getEl().dom.name = lastModifiedPrefix
                    + "/jcr:lastModified";
            this.lastModifiedByParameter.getEl().dom.name = lastModifiedPrefix
                    + "/jcr:lastModifiedBy";
            this.lastModifiedParameter.enable();
            this.lastModifiedByParameter.enable();
        } else {
            this.lastModifiedParameter.getEl().dom.name = null;
            this.lastModifiedByParameter.getEl().dom.name = null;
            this.lastModifiedParameter.disable();
            this.lastModifiedByParameter.disable();
        }
    },

    /**
     * <p>Flushes the current content of the component.</p>
     * <p>If both a reference and uploaded instance is set, only the reference is removed
     * and the uploaded data will be kept intact. This behaviour is used to "overlay"
     * uploaded images with references.</p>
     * <p>This method should be called from every implementing content that uses its own
     * flush method to ensure the internal data structures are handled correctly.</p>
     * @private
     */
    flush: function() {
        if (this.referencedFileInfo) {
            this.referencedFileInfo = null;
        } else if (this.fileInfo) {
            this.fileInfo = null;
        }
        if ((this.referencedFileInfo == null) && (this.fileInfo == null)
                && this.fileNameField) {
            this.fileNameField.setValue("");
        }
        this.validateOnStateChange();

        if (!this.useHTML5) {
            this.deleteFileParameter.enable();
            this.fallbackFileField.fileInput.dom.name = "";
            this.fallbackFileField.setValue("");
        }
    },


    // View --------------------------------------------------------------------------------

    createLockPanel: function() {
        this.isLockPanelCreated = true;
        var parentEl = this.lockPanel.body;
        var itemCnt = this.lockPanel.items.getCount();
        for (var removeIndex = itemCnt - 1; removeIndex >= 0; removeIndex--) {
            this.remove(this.lockPanel.items.itemAt(removeIndex));
        }

        // create icon & text
        var imgHtml;
        if (this.lockIconCls) {
            imgHtml = "<img src=\"" + CQ.Ext.BLANK_IMAGE_URL + "\" alt=\"\" border=\"0\" "
            + "class=\"" + this.lockIconCls + "\"><br>";
        } else {
            imgHtml = "";
        }
        var textHtml = this.cancelInheritanceText;
        var contentHtml = imgHtml + textHtml;
        this.lockTextEl = parentEl.createChild({
            "tag": "div",
            "html": contentHtml
        });

        this.lockTextEl.addListener("click", function() {
            this.switchPropertyInheritance();
        }, this);

        this.lockTextEl.setVisibilityMode(CQ.Ext.Element.DISPLAY);
        if (this.lockPanel._width && this.lockPanel._height) {
            this.setTextElSize(this.lockTextEl, this.lockPanel._width, this.lockPanel._height);
        }

        if (this.lockHintCls) {
            this.lockTextEl.addClass(this.lockHintCls);
        }
    },

    /**
     * <p>Updates the UI to the current state of the component.</p>
     * <p>The correct basic panel (upload/referencing vs. editing) is chosen. All editing
     * stuff is reset to a default stuff. The editing area is notified about the file to
     * display, if applicable.</p>
     * @private
     */
    updateView: function() {

        if (this.editLock) {
            this.containerPanel.getLayout().setActiveItem("lock");
            if (!this.isLockPanelCreated) {
                this.createLockPanel();
            }

        } else {

            var hasData = (this.fileInfo != null) || (this.referencedFileInfo != null);
            this.updateViewBasics(hasData);
            if (hasData) {
                this.createProcessingPanelContents();
            }
        }

        this.doLayout();
    },

    /**
     * Updates the basic components of the UI to the current state of the component.
     * @param {Boolean} hasData True if the component contains data (i.e. a file is
     *        currently uploaded or references)
     * @private
     */
    updateViewBasics: function(hasData) {
        if (!hasData) {
            this.containerPanel.getLayout().setActiveItem("upload");
            if (!this.isUploadPanelCreated) {
                this.createUploadPanel();
            } else {
                this.switchToUploadBase();
            }
            if (this.uploadHintCls) {
                this.body.addClass(this.uploadHintCls);
                if (this.textEl) {
                    this.textEl.addClass(this.uploadHintCls);
                }
            }
        } else {
            if (this.uploadHintCls) {
                this.body.removeClass(this.uploadHintCls);
                if (this.textEl) {
                    this.textEl.removeClass(this.uploadHintCls);
                }
            }
            this.containerPanel.getLayout().setActiveItem("processing");
        }
    },

    /**
     * <p>Creates the panel (used in a <code>CardLayout</code>) that is responsible for
     * editing the managed file.</p>
     * @return {CQ.Ext.Panel} The panel created
     * @private
     */
    createProcessingPanel: function() {
        return new CQ.form.SmartFile.FileInfoDisplay({
            "itemId": "processing",
            "fileNameField": (this.allowFileNameEditing && this.fileNameField
                    ? this.fileNameField : null),
            "parentComponent": this
        });
    },

    /**
     * todo documentation
     * @private
     */
    createProcessingPanelContents: function() {
        var fileInfo = this.getSuitableFileInfo();
        var fileName = fileInfo.fileName;
        var extension = null;
        if (fileName) {
            var extensionPos = fileName.lastIndexOf(".");
            if ((extensionPos >= 0) && (extensionPos < (fileName.length - 1))) {
                extension = fileName.substring(extensionPos + 1, fileName.length)
                        .toLowerCase();
            }
        }
        var icon = this.defaultIcon;
        if (extension && this.extensionToIcon[extension]) {
            icon = this.extensionToIcon[extension];
        }
        var iconResourcesPath = this.iconResources;
        if (iconResourcesPath.charAt(iconResourcesPath.length - 1) != "/") {
            iconResourcesPath += "/";
        }
        var iconUrl = CQ.HTTP.externalize(iconResourcesPath + icon);
        var mimeTypeStr = CQ.I18n.getMessage("unknown");
        if (fileInfo.mimeType) {
            mimeTypeStr = fileInfo.mimeType;
        }
        var sizeStr = CQ.I18n.getMessage("unknown");
        if (fileInfo.size) {
            sizeStr = CQ.Util.formatFileSize(fileInfo.size);
        }
        var fileInfoHtml = CQ.I18n.getMessage("MIME type: {0}<br>Size: {1}",
                [ mimeTypeStr, sizeStr ]);
        if (this.referencedFileInfo) {
            fileInfoHtml += "<br>" + this.getRefText(this.referencedFileInfo.dataPath,
                    fileName);
        }
        if (!this.transferFileName) {
            fileName = this.noFileNameText;
        }
        this.processingPanel.updateContent(fileName, fileInfoHtml, iconUrl);
    },

    /**
     * Returns the text to display in case of file references.
     * @private
     * @param {String} refPath The reference file path
     * @param {String} pathTxt The text to display instead of the path
     * @return {String} The text
     */
    getRefText: function(refPath, pathTxt) {
        var canEditRef = CQ.User.getCurrentUser().hasPermissionOn("update", refPath);
        var refHref = CQ.HTTP.externalize(CQ.shared.XSS.getXSSValue(CQ.shared.HTTP.encodePath(refPath), true));
        var refTxt = CQ.I18n.getMessage("Referenced from:") + " ";
        if (canEditRef) {
            refTxt += "<a href=\"" + refHref + "\" target=\"_blank\" title=\"" +
                    CQ.I18n.getMessage("Click here to open referenced file") +
                    "\" style=\"cursor:pointer;\">";
        }
        refTxt += CQ.shared.XSS.getXSSValue(pathTxt ? pathTxt : refPath);
        if (canEditRef) {
            refTxt += "</a>";
        }
        return refTxt;
    },

    createRevertInheritanceHint: function() {
        var lockHint = this.uploadPanel.body.createChild({
            "tag": "div",
            "cls": this.lockHintCls,
            "html": this.revertInheritanceText
        });
        lockHint.addListener("click", function() {
            this.switchPropertyInheritance();
        }, this);
    },

    /**
     * <p>Creates the panel that is used for uploading a file.</p>
     * <p>The panel contains the HTML5 upload panel (or a fallback panel, if HTML5 upload support
     * is not available or disabled).</p>
     * @private
     */
    createUploadPanel: function() {
        this.isUploadPanelCreated = true;
        var parentEl = this.uploadPanel.body;
        var itemCnt = this.uploadPanel.items.getCount();
        for (var removeIndex = itemCnt - 1; removeIndex >= 0; removeIndex--) {
            this.remove(this.uploadPanel.items.itemAt(removeIndex));
        }

        // create icon & text
        var imgHtml;
        if (this.uploadIconCls) {
            imgHtml = "<img src=\"" + CQ.Ext.BLANK_IMAGE_URL + "\" alt=\"\" border=\"0\" "
            + "class=\"" + this.uploadIconCls + "\"><br>";
        } else {
            imgHtml = "";
        }
        var textHtml = this.uploadText;
        if (!this.allowUpload) {
            textHtml = this.uploadTextReference;
        }
        if (!this.allowFileReference) {
            textHtml = this.uploadTextUpload;
        }
        var contentHtml = imgHtml + textHtml;
        this.textEl = parentEl.createChild({
            "tag": "div",
            "html": contentHtml
        });

        if (this.delayedCreateRevertInheritanceHint && !this.isLockHintCreated) {
            this.createRevertInheritanceHint();
            this.delayedCreateRevertInheritanceHint = false;
            this.isLockHintCreated = true;
        }

        if (!this.useHTML5 && this.allowUpload) {
            this.textEl.addListener("click", function() {
                // fallback: go to download panel
                this.containerPanel.getLayout().setActiveItem("fallback");
                this.fallbackFileField.fileInput.dom.name = this.name;
                this.deleteFileParameter.disable();
            }, this);
        }

        if (this.uploadHintCls) {
            this.textEl.addClass(this.uploadHintCls);
        }
        this.textEl.setVisibilityMode(CQ.Ext.Element.DISPLAY);
        if (this.uploadPanel._width && this.uploadPanel._height) {
            this.setTextElSize(this.textEl, this.uploadPanel._width, this.uploadPanel._height);
        }

        if (this.useHTML5) {
            // Create HTML5 upload
            if (this.uploadHintCls) {
                this.body.addClass(this.uploadHintCls);
            }
            if (this.allowUpload) {
                var self = this;
                (function() {
                    // Add upload field
                    var height = self.uploadPanel._height ? self.uploadPanel._height : self.ownerCt.getHeight();
                    if (self.textEl) {
                        height = self.textEl.getHeight();
                    }
                    var width = self.uploadPanel._width ? self.uploadPanel._width : self.ownerCt.getWidth();
                    self.uploadField = new CQ.html5.form.FileUploadField({
                        name: this.name,
                        html5Upload: true,
                        multiple: false,
                        mimeTypes: this.mimeTypes,
                        mimeTypesDescription: this.mimeTypesDescription,
                        noDisplay: true,
                        targetEl: this,
                        renderTo: self.uploadPanel.id,
                        fileInputStyle: {
                            "font-size": "1000px",
                            "position": "absolute",
                            "top": 0,
                            "left": 0,
                            "height": height + "px",
                            "width": width + "px"
                        }
                    });

                    // Update parent style
                    var html5ParentEl = self.uploadField.el.parent();
                    html5ParentEl.setStyle("position", "absolute");
                    html5ParentEl.setStyle("top", "0");
                    html5ParentEl.setStyle("left", "0");
                    html5ParentEl.setStyle("height", height + "px");
                    html5ParentEl.setStyle("width", width + "px");
                }).call(this);
            }
        }
    },

    /**
     * Switches the UI to display the upload's progress.
     * @private
     */
    switchToUploadProgress: function() {
        if (this.removeUploadPanelClsOnProgress && this.uploadPanelCls) {
            this.uploadPanel.removeClass(this.uploadPanelCls);
        }
        var parentEl = this.uploadPanel.body;
        if (this.useHTML5) {
            this.textEl.setVisible(false);
        }
        if (!this.progressBar) {
            this.progressBar = new CQ.Ext.ProgressBar( {
                "text": "&nbsp;"
            } );
            var divStyle = "padding-left: 5px; padding-right: 5px; "
                    + "position: absolute; top: 0px; left: 0px;";
            if (this.fixedHeight) {
                divStyle += " height: " + this.fixedHeight + "px";
            }
            this.progressBarDiv = parentEl.createChild({
                "tag": "div",
                "style": divStyle
            });
            this.progressBarDiv.setVisibilityMode(CQ.Ext.Element.DISPLAY);
            if (this.uploadPanel._width && this.uploadPanel._height) {
                this.setProgressBarSize(this.uploadPanel._width, this.uploadPanel._height);
            }
            this.progressBar.render(this.progressBarDiv);
            this.progressBar.updateProgress(0, CQ.I18n.getMessage("Uploading ..."));
        } else {
            this.progressBarDiv.setVisible(true);
        }
    },

    /**
     * Switches the UI to display the upload panel.
     * @private
     */
    switchToUploadBase: function() {
        if (this.progressBarDiv) {
            this.progressBarDiv.setVisible(false);
        }
        if (this.removeUploadPanelClsOnProgress && this.uploadPanelCls) {
            this.uploadPanel.addClass(this.uploadPanelCls);
        }
        this.textEl.setVisible(true);
    },

    /**
     * Sets the size of textEl (using the padding-top CSS property) to center it vertically
     * in its parent container.
     * @param {Number} width The width of the parent container
     * @param {Number} height The height of the parent container
     * @private
     */
    setTextElSize: function(element, width, height) {
        if (element) {
            if (!this.msgHeight) {
                this.msgHeight = element.getHeight();
            }
            var paddingY = Math.round((height - this.msgHeight) / 2);
            if (paddingY > 0) {
                element.setStyle("padding-top", paddingY + "px");
            }
            // Change upload field height is required if the widget is not on the first tab
            if (this.uploadField) {
                if (this.textEl || this.lockTextEl) {
                    // Taking either the text element height or the lock text element height if available and > 0 to resize the upload field accordingly
                    height = this.textEl && this.textEl.getHeight() > 0 ? this.textEl.getHeight() : (this.lockTextEl && this.lockTextEl.getHeight() > 0 ? this.lockTextEl.getHeight() : height);
                }
                this.uploadField.fileInput.setStyle("width", width + "px");
                this.uploadField.fileInput.setStyle("height", height + "px");
                this.uploadField.el.parent().setStyle("width", width + "px");
                this.uploadField.el.parent().setStyle("height", height + "px");
            }
        }
    },

    /**
     * Sets the size of the progress bar to the specified size.
     * @param {Number} width The width
     * @param {Number} height The height
     * @private
     */
    setProgressBarSize: function(width, height) {
        if (this.progressBarDiv) {
            this.progressBarDiv.setSize(width, height);
        }
    },


    // Processing --------------------------------------------------------------------------

    /**
     * <p>Removes the currently edited file and propagates the change to the UI.</p>
     * <p>After the method has executed, the component is ready for uploading or referencing
     * a new file.</p>
     * @private
     */
    flushFile: function() {
        this.flush();
        this.syncFormElements();
        this.updateView();
    },


    // Drag & Drop implementation ----------------------------------------------------------

    /**
     * Initializes Drag &amp; Drop for this component.
     * @private
     */
    initializeDragAndDrop: function() {
        if (this.allowFileReference && this.ddGroups) {
            if (typeof(this.ddGroups) == "string") {
                this.ddGroups = [ this.ddGroups ];
            }
            var parentScope = this;
            var target = new CQ.wcm.EditBase.DropTarget(this.el, {
                notifyDrop: function(dragObject, evt, data) {
                    if (dragObject && dragObject.clearAnimations) {
                        dragObject.clearAnimations(this);
                    }
                    if (dragObject.isDropAllowed(this)) {
                        var isTaken = parentScope.handleDrop(data);
                        if (isTaken) {
                            evt.stopEvent();
                        }
                        return isTaken;
                    }
                }
            });

            var dialog = this.getToplevel();
            if (dialog) {
                dialog.on("activate", function(dialog) {
                    if (dialog && dialog.el && this.highlight) {
                        var dialogZIndex = parseInt(dialog.el.getStyle("z-index"), 10);
                        if (!isNaN(dialogZIndex)) {
                            this.highlight.zIndex = dialogZIndex + 1;
                        }
                    }
                }, target);

                dialog.on("deactivate", function(dialog) {
                    if (dialog && dialog.el && this.highlight) {
                        var dialogZIndex = parseInt(dialog.el.getStyle("z-index"), 10);
                        if (!isNaN(dialogZIndex)) {
                            this.highlight.zIndex = dialogZIndex + 1;
                        }
                    }
                }, target);
            }
            for (var i = 0; i < this.ddGroups.length; i++) {
                target.addToGroup(this.ddGroups[i]);
            }
            target.removeFromGroup(CQ.wcm.EditBase.DD_GROUP_DEFAULT);

            var accept = this.ddAccept;
            if (accept) {
                if (!CQ.Ext.isArray(accept)) {
                    var reg = new RegExp("[ ;]+", "g");
                    accept = accept.split(reg);
                }
                target.ddAccept = accept;
            }

            this.dropTargets = [];
            this.dropTargets.push(target);
        }
    },

    /**
     * Handler that reacts on objects that were dropped on the component.
     * @param {Object} dragData Description of the object that has been dropped on the
     *        component
     */
    handleDrop: function(dragData) {
        if (this.handleDropBasics(dragData)) {
            this.syncFormElements();
            this.updateView();
            return true;
        }
        return false;
    },

    /**
     * <p>Handler for basic drop handling.</p>
     * <p>If a component overrides {@link #handleDrop}, it should usually call
     * handleDropBasics to execute some basic tasks (e.g. loading information about the
     * dropped file and doing some required event dispatching.)</p>
     * @param {Object} dragData
     * @private
     */
    handleDropBasics: function(dragData) {
        if (dragData.records && dragData.single) {
            var record = dragData.records[0];
            var fileRefPath = record.get("path");
            this.referencedFileInfo = this.resolveReference(fileRefPath, this.dataPath);
            var fileName = record.get("name");
            if (fileName) {
                this.referencedFileInfo.fileName = fileName;
            }
            this.referencedFileInfo.url = this.createRefUrl(
                    this.referencedFileInfo);
            this.referencedFileInfo.fallbackUrl = this.createFallbackRefUrl(
                    this.referencedFileInfo);
            this.validateOnStateChange();
            return true;
        }
        return false;
    },


    // Internal event handling -------------------------------------------------------------

    /**
     * Executes when one or more files have been selected, for browsers which support multi-selection
     * @param {Array} files
     */
    onFileSelected: function(uploadField, files) {
        if (this.useHTML5 && files.length > 0) {
            this.handleUploadStart();

            var file = files[0];

            var xhr = new XMLHttpRequest();

            xhr.onreadystatechange = this.handleUploadLoad.createDelegate(this, [file, xhr], 0);

            xhr.upload.addEventListener("progress", this.handleUploadProgress.createDelegate(this, [file], 0), false);
            xhr.upload.addEventListener("error", this.handleUploadError.createDelegate(this, [file, xhr], 0), false);

            this.uploadPath = this.dataPath;
            this.uploadName = this.name;
            if (this.name == "./*") {
                this.uploadName = file.name;
            }
            var method;
            var sendData;
            if (window.FormData !== undefined) {
                method = "POST";
                sendData = new FormData();
                sendData.append(this.uploadName + CQ.html5.form.SmartFile.PARAM_TEMP_NODE_SUFFIX, file);
                sendData.append(CQ.Sling.CHARSET, "utf-8");
            } else {
                this.uploadPath = CQ.Sling.getContentPath(this.uploadName + CQ.html5.form.SmartFile.PARAM_TEMP_NODE_SUFFIX, this.uploadPath);
                method = "PUT";
                sendData = file;
            }

            xhr.open(method, CQ.shared.HTTP.getXhrHookedURL(CQ.HTTP.externalize(CQ.HTTP.encodePath(this.uploadPath)), method), true);
            xhr.send(sendData);
        }

        return true;
    },

    /**
     * Handles a primarily successful upload by synchronizing the form elements and
     * updating the view.
     * @return {Boolean} True, if the upload is still valid/successful after executing
     *         the handler
     * @private
     */
    onUploaded: function() {
        this.syncFormElements();
        this.updateView();
        return true;
    },


    // HTML5 component -----------------------------------------------------------------

    /**
     * Formats the specified time.
     * @private
     * @param {Number} time The time
     * @return {String} The formatted time
     */
    formatTimeLeft: function(time) {
        if (time > 86399) {
            time = Math.round(time / 86400);
            if (time == 1) {
                return CQ.I18n.getMessage("{0} day", [time]);
            } else {
                return CQ.I18n.getMessage("{0} days", [time]);
            }
        } else if (time > 3599) {
            time = new String(time / 3600);
            var point = time.indexOf(".");
            if (point > 0) {
                if (time.charAt(point + 1) == "0") {
                    time = time.substring(0, point);
                } else {
                    time = time.substring(0, point + 2);
                }
            }
            if (time == 1) {
                return CQ.I18n.getMessage("{0} hour", [time]);
            } else {
                return CQ.I18n.getMessage("{0} hours", [time]);
            }
        } else if (time <= 3600 && time > 59) {
            time = Math.round(time / 60) + "";
            if (time == 1) {
                return CQ.I18n.getMessage("{0} minute", [time]);
            } else {
                return CQ.I18n.getMessage("{0} minutes", [time]);
            }
        } else {
            if (time == 1) {
                return CQ.I18n.getMessage("{0} second", [time]);
            } else {
                return CQ.I18n.getMessage("{0} seconds", [time]);
            }
        }
    },

    /**
     * Estimates the time left until uploading will be complete based on the
     * time passed since the upload started and the amount of bytes already
     * transmitted.
     * @private
     * @param {Number} complete The amount of bytes transmitted
     * @param {Number} total The total amount of bytes to transmit
     * @return {String} The estimated time
     */
    estimateTimeLeft: function(complete, total) {
        var timeUsed = new Date().valueOf() - this.startTime;
        var timeLeft = Math.round(timeUsed * (total - complete) / complete / 1000);
        return this.formatTimeLeft(timeLeft);
    },

    /**
     * Handles the dialog start event.
     * @private
     */
    handleDialogStart: function() {
        if (this.pendingFiles > 0) {
            this.pendingFiles = 0;
        }
    },

    /**
     * Handles the upload load event.
     * @private
     * @param {Object} request The XHR request
     */
    handleUploadLoad: function(file, request) {
        if (request.readyState === 4) {
            this.uploadPanel.setVisible(false);
            if (CQ.HTTP.isOkStatus(request.status)) {
                this.handleUploadSuccess(file, request.responseText);
            } else {
                this.handleUploadError(file, request);
            }
        }
    },

    /**
     * Handles the upload start event.
     * @private
     * @param {Object} file The file to upload
     */
    handleUploadStart: function(file) {
        this.hasUploadErrors = false;
        this.startTime = new Date().valueOf();
        this.switchToUploadProgress();
        this.uploadPanel.setVisible(true);
        return true;
    },

    /**
     * Handles the upload progress event.
     * @private
     * @param {Object} file The file being uploaded
     * @param {Object} progress The progress information
     */
    handleUploadProgress: function(file, progress) {
        var message = CQ.I18n.getMessage("{0} of {1} - {2}", [CQ.Util.formatFileSize(progress.loaded), CQ.Util.formatFileSize(progress.total), this.estimateTimeLeft(progress.loaded, progress.total)]);
        this.progressBar.updateProgress(progress.loaded / progress.total, message);
    },

    /**
     * Handles the upload success event.
     * @private
     * @param {Object} file The uploaded file
     * @param {String} response The response text
     */
    handleUploadSuccess: function(file, response) {
        var isSuccess = false;
        var oldFileInfo = this.fileInfo;
        var builtResponse = CQ.HTTP.buildPostResponseFromHTML(response);
        var isFormData = window.FormData !== undefined;
        if (isFormData ? CQ.HTTP.isOk(builtResponse) : response === "") {
            var path;
            try {
                if (isFormData) {
                    try {
                        path = builtResponse.headers[CQ.HTTP.HEADER_PATH];
                        path = CQ.Sling.getContentPath(this.uploadName + CQ.html5.form.SmartFile.PARAM_TEMP_NODE_SUFFIX, path);
                    } catch (e) {
                        CQ.Log.error("CQ.html5.form.SmartFile#handleUploadSuccess: " + e.message);
                    }
                } else {
                    path = this.uploadPath;
                }

                try {
                    this.fileInfo = this.resolveReference(path, this.dataPath);
                    this.fileInfo.fileName = file.name;
                } catch (e) {
                    this.fileInfo = {
                        "fileName": file.name,
                        "dataPath": path,
                        "url": CQ.HTTP.externalize(path),
                        "size": file.size
                    };
                }
                this.isUploaded = true;
                isSuccess = (this.onUploaded() !== false);
                if (this.transferFileName && this.fileNameField) {
                    this.fileNameField.setValue(this.fileInfo.fileName);
                } else {
                    this.fileNameField.setValue("");
                }
                this.validateOnStateChange();
            } catch (e) {
                CQ.Log.error("CQ.html5.form.SmartFile#handleUploadSuccess: " + e.message);
            }
        } else {
            CQ.Log.error("CQ.html5.form.SmartFile#handleUploadSuccess: response not ok");
        }
        var message;
        if (!isSuccess) {
            this.fileInfo = oldFileInfo;
            this.hasUploadErrors = true;
            message = CQ.I18n.getMessage("Error uploading '{0}'", [file.name]);
            this.notify(message, CQ.html5.form.SmartFile.STATUS_ERROR);
        }
    },

    /**
     * Handles the upload error event.
     * @private
     * @param {Object} file The uploaded file
     * @param {Object} request Request
     */
    handleUploadError: function(file, request) {
        this.hasUploadErrors = true;
        var message = CQ.I18n.getMessage("Failed to upload '{0}': {1}", [CQ.shared.XSS.getXSSValue(file.name), request.responseText]);
        this.notify(message, CQ.html5.form.SmartFile.STATUS_ERROR);
//        if (status != SWFUpload.UPLOAD_ERROR.FILE_CANCELLED) {
//            // todo handle correctly
//            /*
//            if (this.serverFileInstance) {
//                this.revertFile();
//            }
//            */
//        }
    },

    /**
     * Handles the upload complete event.
     * @private
     */
    handleUploadComplete: function() {
        this.startTime = 0;
        this.pendingFiles = 0;
    },

    /**
     * Should reset the field to the original state. currently just "flushes" the data.
     */
    // overriding CQ.form.CompositeField#reset
    reset: function() {
        // todo implement correctly
        this.flush();
        CQ.html5.form.SmartFile.superclass.reset.call(this);
    },

    // Helpers -----------------------------------------------------------------------------

    /**
     * Displays notification messages to the user.
     * @param {String} message The message to display
     * @param {Number} status Message status; defined by constants prefixed by STATUS_
     * @private
     */
    notify: function(message, status) {
        // todo use better mechanism when available
        CQ.Ext.Msg.alert(CQ.I18n.getMessage("Upload"), message);
    },

});

/**
 * The suffix to append to the node name for the temporary node name.
 * File will be uploaded to a temporary location, and clicking on OK will save it at its final location
 * @static
 * @final
 * @type String
 * @private
 */
CQ.html5.form.SmartFile.PARAM_TEMP_NODE_SUFFIX = ".sftmp";

/**
 * The suffix to append to the widget's name for the file name parameter.
 * @static
 * @final
 * @type String
 * @private
 */
CQ.html5.form.SmartFile.PARAM_FILENAME_SUFFIX = "Name";

/**
 * The suffix to append to the widget's name for the file reference parameter.
 * @static
 * @final
 * @type String
 * @private
 */
CQ.html5.form.SmartFile.PARAM_REFERENCE_SUFFIX = "Reference";

/**
 * Default suffix used for requesting original versions of a requested image from DAM
 * @static
 * @final
 * @type String
 * @private
 */
CQ.html5.form.SmartFile.DAM_RENDITION_SUFFIX = "/jcr:content/renditions/original";

/**
 * Name of the web rendition (without extension)
 * @static
 * @final
 * @type String
 * @private
 */
CQ.html5.form.SmartFile.DAM_WEB_RENDITION_NAME = "cq5dam.web.1280.1280";

/**
 * Path where the DAM renditions are located
 * @static
 * @final
 * @type String
 * @private
 */
CQ.html5.form.SmartFile.DAM_RENDITIONS_PATH = "/jcr:content/renditions/";

/**
 * Message status: Success
 * @static
 * @final
 * @type Number
 * @private
 */
CQ.html5.form.SmartFile.STATUS_SUCCESS = 0;

/**
 * Message status: Error
 * @static
 * @final
 * @type Number
 * @private
 */
CQ.html5.form.SmartFile.STATUS_ERROR = 1;

/**
 * Message status: Submission
 * @static
 * @final
 * @type Number
 * @private
 */
CQ.html5.form.SmartFile.STATUS_SUBMISSION = 2;

/**
 * Counter for creating page-unique IDs required for Selenium testing
 * @static
 * @type Number
 * @private
 */
CQ.html5.form.SmartFile.ID_COUNTER = 0;

// register xtype
CQ.Ext.reg('html5smartfile', CQ.html5.form.SmartFile);
