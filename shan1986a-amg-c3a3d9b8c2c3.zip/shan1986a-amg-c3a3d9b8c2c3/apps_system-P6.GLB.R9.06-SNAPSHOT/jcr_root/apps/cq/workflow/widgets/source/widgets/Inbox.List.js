/*
 * Copyright 1997-2010 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */

/**
 * Work item list for the workflow inbox.
 *
 * @class CQ.workflow.Inbox.List
 * @extends CQ.Ext.grid.GridPanel
 */
CQ.workflow.Inbox.List = CQ.Ext.extend(CQ.Ext.grid.GridPanel, {
    pageSize:40,
    
    store:null,
    
    constructor: function(config) {
        var inbox = this;
        
        this.store = new CQ.Ext.data.Store({
            autoLoad:false,
            proxy: new CQ.Ext.data.HttpProxy({
                url: CQ.HTTP.externalize("/libs/cq/workflow/content/inbox/list.json"),
                method:"GET"
            }),
            reader: new CQ.Ext.data.JsonReader({
                root:"items",
                id: "item",
                totalProperty:"results",
                fields: [
                    "title",
                    "description",
                    "inboxItemType",
                    "computedItemType",
                    "actionNames",
                    "payload",
                    CQ.shared.XSS.getXSSPropertyName("payload"),
                    "payloadPath",
                    CQ.shared.XSS.getXSSPropertyName("payloadPath"),
                    "payloadTitle",
                    "payloadType",
                    "payloadSummary",
                    "currentAssignee",
                    "startTime",
                    "comment",
                    "workflowTitle",
                    "participant",
                    "dialog",
                    "metaData",
                    "lastModifiedBy",
                    "lastModified",
                    "replication",
                    "inWorkflow",
                    "workflows",
                    "lockedBy",
                    "monthlyHits",
                    "timeUntilValid",
                    "onTime",
                    "offTime",
                    "scheduledTasks"
                ]
            }),
            listeners:{
                beforeload:function(store, opts) {
                    if (!opts.params) opts.params = {};
                    
                    // add filter params
                    var fields = CQ.workflow.InboxUtil.getFilterFields();
                    for (var i=0; i<fields.length; i++) {
                        var field = fields[i];
                        var val = field.getValue();
                        if (val && (val != "")) {
                            opts.params[field.getName()] = val;
                        } else if (opts.params[field.getName()]) {
                            delete opts.params[field.getName()];
                        }
                    }
                },
                exception: function(obj, action, data, it, response) {
                        CQ.shared.HTTP.handleForbidden(response);
                }
            }
        });
        
        config.ctxMenu = [];
        for(var i = 0; i < config.tbar.length; ++i) {
            if(config.tbar[i].menuId == "cq-workflow-inbox-actions") {				
                var cfg = CQ.Ext.copyTo({}, config.tbar[i], ["id", "text", "handler", "listeners", "supportedItemTypes"]);
                cfg.id = cfg.id + "-ctxmenu";
                // Added as part of R6 Release Step Back Customization
				if(config.tbar[i].text != CQ.I18n.getMessage("Step Back")){
					config.ctxMenu.push(cfg);
				}
            }
        }
        
        var bbar = new CQ.Ext.PagingToolbar({
            pageSize:config.pageSize ? config.pageSize : this.pageSize,
            store:this.store,
            displayInfo:true,
            displayMsg:CQ.I18n.getMessage("Displaying items {0} - {1} of {2}"),
            emptyMsg:CQ.I18n.getMessage("No items to display")
        });
        
        CQ.Util.applyDefaults(config, {
            id:CQ.workflow.Inbox.List.ID,
            loadMask:true,
            stripeRows:true,
            viewConfig:{
                emptyText:CQ.I18n.getMessage("There are currently no items in your inbox."),
                deferEmptyText:true,
                forceFit:true
            },
            store:this.store,
            sm:new CQ.Ext.grid.RowSelectionModel({ singleSelect:false }),
            bbar:bbar,
            listeners: {
                rowcontextmenu:function(grid, index, e) {
                    if (e.altKey) return;

                    var xy = e.getXY();
                    e.stopEvent();

                    var sm = grid.getSelectionModel();
                    if (!sm.hasSelection()) {
                        sm.selectRow(index);
                    } else if (!sm.isSelected(index)) {
                        sm.selectRow(index);
                    }

                    if (!grid.contextMenu) {
                        grid.contextMenu = new CQ.Ext.menu.Menu({
                            "items": config.ctxMenu
                        });
                    }

                    grid.contextMenu.showAt(xy);

                    // enable the menu for the current selection:
                    var menuItemIndex;
                    var records = this.getSelectionModel().getSelections();
					
                    if (records && records.length > 0) {
                        for(menuItemIndex=0; menuItemIndex<grid.contextMenu.items.length; menuItemIndex++) {
                            var menuItem = grid.contextMenu.get(menuItemIndex);
                            if (menuItem.supportedItemTypes) {
                                // loop over all records and only enable menu items available for all records
                                var recordNum;
                                var showItem = true;
                                // Added as part of R6 Release Step Back Customization
								if(menuItem.text==CQ.I18n.getMessage("Step Back")){
									showItem = false;
								}
                                for (recordNum=0; recordNum < records.length; recordNum++){
                                    var record = records[recordNum];
                                    var inboxItem = record.get("inboxItemType");
                                    if (!menuItem.supportedItemTypes[inboxItem]) {
                                        showItem = false;
                                        break;
                                    }
                                }
                                if (showItem) {
                                    menuItem.enable();
                                } else {
                                    menuItem.disable();
                                }
                            } else {
                                menuItem.enable();
                            }
                        }
                    }

                }
            }
        });
        CQ.workflow.Inbox.List.superclass.constructor.call(this, config);
    },
    
    initComponent: function() {
        CQ.workflow.Inbox.List.superclass.initComponent.call(this);
        
        this.on("rowdblclick", function(inbox, index, e) {
            inbox.open();
        });
        
        this.store.load({
            params:{
                start:0,
                limit:this.pageSize
            }
        });
    },
    
    reload: function() {
        this.store.reload();
    },
    
    open: function() {
        var records = this.getSelectionModel().getSelections();
        for (var i = 0; i < records.length; i++) {
            var record = records[i];
            var url;
            if (CQ.workflow.InboxUtil.isProjectTask(record)) {
                url = CQ.workflow.InboxUtil.getProjectAdminUrl(record);
            } else if (record.get("payloadPath")) {
                url = CQ.HTTP.externalize(record.get("payload"));
            }

            if (url) {
                // check for multi window mode
                if (CQ.wcm.SiteAdmin.multiWinMode == undefined) {
                    var wm = CQ.User.getCurrentUser().getPreference("winMode");
                    CQ.wcm.SiteAdmin.multiWinMode = (wm != "single");
                }

                if (CQ.wcm.SiteAdmin.multiWinMode) {
                    CQ.shared.Util.open(url);
                } else {
                    CQ.shared.Util.load(url);
                }
            }
        }
    }
});

CQ.workflow.Inbox.List.ID = "cq-workflow-inbox-list";