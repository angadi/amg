{
    id:"cq-workflow-inbox-back",
    menuId:"cq-workflow-inbox-actions",
    supportedItemTypes: { FailureItem: true, WorkItem: true },
    disabled:true,
    hidden:true, 
    ranking:60,
    text:CQ.I18n.getMessage("Step Back"),
    sc:{
        key:"b",
        alt:true,
        stopEvent:true,
        handler:function() {
            var action = CQ.Ext.getCmp("cq-workflow-inbox-back");
            if (!action.disabled) {
                action.handler.call(action);
            }
        }
    },
    handler: function() {
        var inbox = CQ.workflow.InboxUtil.getInbox();
        var items = inbox.getSelectionModel().getSelections();
        var action = CQ.Ext.getCmp("cq-workflow-inbox-back");
        
        action.stepBackItems.call(action, items, 0);
    },
    stepBackItems: function(items, index) {
        if(index >= items.length) {
            CQ.workflow.InboxUtil.getInbox().reload();
            return;
        }
        
        var item = items[index];
        var title = CQ.shared.Util.ellipsis(CQ.workflow.InboxUtil.getPayloadTitle(item.get("payload"), item), 60, true);

        var panel = {
            xtype:"dialogfieldset",
            title: CQ.shared.Util.ellipsis(item.get("title"), 60, true) + " (" + title + ")",
            collapsed:false,
            collapsible:false,
            items:[{
                xtype:"combo",
                id:"cq.workflow.inbox.back.combo",
                anchor:CQ.themes.Dialog.ANCHOR,
                store:new CQ.Ext.data.Store({
                    proxy: new CQ.Ext.data.HttpProxy({
                        url:item.id + ".backroutes.json",
                        method:"GET"
                    }),
                    reader: new CQ.Ext.data.JsonReader({
                        totalProperty: "results",
                        root:"backroutes"
                    }, [ {name: "rid"}, {name: "label"}, {name: CQ.shared.XSS.getXSSPropertyName("label")} ])
                }),
                name:"backroute-" + item.id,
                fieldLabel:CQ.I18n.getMessage("Previous Step"),
                displayField:"label",
                valueField:"rid",
                hiddenName:"backroute-" + item.id,
                title:CQ.I18n.getMessage("Available Destinations"),
                selectOnFocus:true,
                triggerAction: "all",
                allowBlank:false,
                editable:false,
                mode:"local",
                tpl: new CQ.Ext.XTemplate(
                    '<tpl for=".">',
                        '<div class="x-combo-list-item">',
                            '{[CQ.shared.XSS.getXSSTablePropertyValue(values, \"label\", 90)]}',
                        '</div>',
                    '</tpl>'
                )
            },{
                xtype:"textarea",
                name:"comment-" + item.id,
                height:100,
                anchor:CQ.themes.Dialog.ANCHOR,
                fieldLabel:CQ.I18n.getMessage("Comment"),
                fieldDescription:CQ.I18n.getMessage("Optional comment to describe what has been done.")
            },{
                xtype:"hidden",
                name:"item",
                value:item.id
            }]
        };
        
        var action = this;
        var dlgCfg = {
            xtype: "dialog",
            title: CQ.Util.patchText(CQ.I18n.getMessage("Step Back Item {0} of {1}"), [index + 1, items.length]),
            formUrl:"/bin/workflow/inbox",
            buttons: [CQ.Dialog.OK, {
                text: CQ.I18n.getMessage("Skip"),
                handler: function() {
                    /* show next dialog after small delay */
                    CQ.WCM.unregisterDialog("cq.workflow.inbox.back.dialog");
                    action.stepBackItems.defer(200, action, [items, index + 1]);
                }
            }, CQ.Dialog.CANCEL],
            params:{
                cmd:"advanceBack",
                "_charset_":"utf-8"
            },
            items:{
                xtype:"panel",
                items:[{
                    xtype:"panel",
                    id:"cq-workflow-inbox-back-msg",
                    border:false,
                    hidden:true,
                    html:CQ.I18n.getMessage("There are no items that can step back.")
                }].concat([panel])
            },
            success: function(){
                CQ.WCM.unregisterDialog("cq.workflow.inbox.back.dialog");
                action.stepBackItems.defer(200, action, [items, index + 1]);
            },
            failure:function(){
                CQ.Ext.Msg.alert(CQ.I18n.getMessage("Error"),
                        CQ.I18n.getMessage("Could not step back workflow step"));
                        
                CQ.WCM.unregisterDialog("cq.workflow.inbox.back.dialog");
            }
        };
        var dlg = CQ.WCM.getDialog(dlgCfg, "cq.workflow.inbox.back.dialog");
        
        dlg.on("hide", function() {
            if (!this.noUnregisterOnHide) {
                CQ.WCM.unregisterDialog("cq.workflow.inbox.back.dialog");
            }
        }, dlg);
        
        dlg.on("show", function() {
            if (!this.mask) {
                this.mask = new CQ.Ext.LoadMask(this.items.get(0).bwrap, {});
            }
            this.mask.show();
            this.buttons[0].setDisabled(true);
            
            var dlg = this;

            var combo = CQ.Ext.getCmp("cq.workflow.inbox.back.combo");
            combo.setDisabled(true);

            combo.store.proxy.url = item.id + ".backroutes.json";
            combo.store.on("load", function(ds, records, o) {
                var c = CQ.Ext.getCmp(o.comboID);

                dlg.mask.hide();
                
                if (records.length > 0) {
                    dlg.buttons[0].setDisabled(false);
                    c.setValue(records[0].get("rid"));

                    if (records.length > 1) {
                        c.setDisabled(false);
                    } else {
                        c.setDisabled(true);
                    }

                    c.store.isLoaded = true;
                } else {
                    CQ.Ext.getCmp("cq-workflow-inbox-back-msg").setVisible(true);
                    c.ownerCt.ownerCt.remove(c.ownerCt);
                }
            });
            combo.store.load({
                comboID:combo.id
            });
        });
        
        dlg.on("beforesubmit", function() {
            var combo = CQ.Ext.getCmp("cq.workflow.inbox.back.combo");
            if (combo) {
                combo.setDisabled(false);
            }
            this.noUnregisterOnHide = true;
            return true;
        }, dlg);
        
        dlg.show();
    },
    tooltip: {
        title:CQ.I18n.getMessage("Step Back") + " (Alt+b)",
        text:CQ.I18n.getMessage("Go one step back in the workflow"),
        autoHide:true
    },
    listeners:{
        render:CQ.workflow.InboxUtil.registerForInboxSelection
    }
}