use(function () {

    var randomId = Math.floor((Math.random() * 10000000000000000000) + 1);

    return {
        randomId: randomId,
    };
});