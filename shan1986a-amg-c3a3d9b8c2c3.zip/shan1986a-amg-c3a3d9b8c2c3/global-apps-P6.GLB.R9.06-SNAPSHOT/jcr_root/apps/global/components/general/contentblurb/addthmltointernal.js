/*
 * This function will check that selected link is internal.
 * if link is external do nothing otherwise add .html in url
 */
use(function () {
    var url = "";
    url = granite.resource.properties["imageLinkto"];
    if(url && url.startsWith("/")) {
    	 if(url && url.startsWith("/content/dam")) {
    		 url = url;
    	 } else {
    		 url = url + ".html";
    	 }
    } else {
         url = url;
    }
    return {
        url: url,
    };
});